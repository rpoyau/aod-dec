"""Read existing artifacts only; this does not execute the model or test suite."""
from pathlib import Path
import collections
import hashlib
import json
import re

FIX = Path(__file__).resolve().parents[1]
REPO = FIX.parent / 'AOD_DEC_MANUAL_PATCH_2026-11-14/aod-dec'
checks = []
bindings = {}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(relative):
    path = FIX / relative
    bindings[relative] = digest(path)
    return json.loads(path.read_text())


def check(name, value, detail=None):
    row = {'check': name, 'status': 'PASS' if value else 'FAIL'}
    if detail is not None:
        row['detail'] = detail
    checks.append(row)


def hash_map(name, mapping, root):
    bad = [name for name, wanted in mapping.items()
           if not (root / name).is_file() or digest(root / name) != wanted]
    check(name, not bad, {'files': len(mapping), 'mismatches': bad})


def parse_tests(relative):
    path = FIX / relative
    bindings[relative] = digest(path)
    text = path.read_text()
    rows = []
    current = None
    for line in text.splitlines():
        start = re.match(r'^test\S* \(([^)]+)\)', line)
        if start:
            current = start[1].removeprefix('tests.')
        result = re.search(r'\.\.\. (ok|FAIL|ERROR|skipped .*)$', line)
        if result and current:
            rows.append({'id': current, 'result': result[1]})
            current = None
    totals = re.findall(r'^Ran (\d+) tests? in ([0-9.]+)s$', text, re.M)
    return {'rows': rows, 'reported_count': int(totals[-1][0]) if totals else None,
            'finished_ok': bool(re.search(r'^OK(?: \(skipped=\d+\))?$', text, re.M))}


inventory = read('validation/test-inventory.json')
check('inventory_has_540_unique_ids', inventory['count'] == len(inventory['ids']) == len(set(inventory['ids'])) == 540)
suite = {}
pending = []
for mode in ('normal', 'optimized'):
    record = read(f'validation/unittest-{mode}.execution.json')
    parsed = parse_tests(f'validation/unittest-{mode}.stderr.log')
    bindings[f'validation/unittest-{mode}.stdout.log'] = digest(FIX / f'validation/unittest-{mode}.stdout.log')
    if record['status'] == 'RUNNING':
        pending.append(f'{mode} suite completion')
        suite[mode] = {'status': 'PENDING', 'completed_records': len(parsed['rows'])}
        continue
    counts = collections.Counter(x['result'].split(' ')[0] for x in parsed['rows'])
    ids = [x['id'] for x in parsed['rows']]
    check(f'{mode}_inventory_and_log_agree', len(ids) == len(set(ids)) == 540 and set(ids) == set(inventory['ids']))
    check(f'{mode}_outcomes_match_record', record['status'] == 'PASS' and record['exit_code'] == 0
          and parsed['finished_ok'] and parsed['reported_count'] == record['tests_run'] == 540
          and counts == {'ok': 538, 'skipped': 2}
          and record['passed'] == 538 and record['skipped'] == 2)
    suite[mode] = {'status': 'PASS', 'tests_run': len(ids), 'passed': counts['ok'],
                   'skipped': [x for x in parsed['rows'] if x['result'].startswith('skipped')]}
if all(suite[m]['status'] == 'PASS' for m in suite):
    check('same_exact_skips_in_both_modes', suite['normal']['skipped'] == suite['optimized']['skipped'])

before = read('validation/source-before.json')
hash_map('validation_before_matches_current_files', before, REPO)
if (FIX / 'validation/source-after.json').exists():
    after = read('validation/source-after.json')
    check('validation_before_after_identical', before == after, {'files': len(before)})
else:
    pending.append('validation/source-after.json')
if (FIX / 'validation/RESULTS.json').exists():
    validation = read('validation/RESULTS.json')
    check('final_validation_report_matches_execution_records', validation['status'] == 'PASS'
          and validation['executions'] == [read(f'validation/unittest-{m}.execution.json') for m in ('normal', 'optimized')]
          and validation['source_files'] == len(before) and validation['source_changes_during_validation'] == [])
    check('final_validation_driver_hash', validation['driver_sha256'] == digest(FIX / 'run_validation.py'))
else:
    pending.append('validation/RESULTS.json')

author = {}
for component, key in [('signs', 'owned_files'), ('store', 'owned_files'), ('history', 'source_sha256')]:
    author[component] = read(f'{component}/RESULTS.json')
    check(f'{component}_reported_pass', author[component]['status'] == 'PASS')
    hash_map(f'{component}_owned_sources_match', author[component][key], REPO)
    if component == 'signs':
        hash_map('signs_author_artifact_hashes', author[component]['artifacts'], FIX / component)
    for mode in ('normal', 'optimized'):
        filename = f'{component}/tests-{mode}.log' if component != 'history' else f"history/{author[component]['tests'][mode]['log']}"
        parsed = parse_tests(filename)
        expected = {'signs': 9, 'store': 42, 'history': 61}[component]
        check(f'{component}_{mode}_log_count', parsed['finished_ok'] and parsed['reported_count'] == len(parsed['rows']) == expected
              and all(x['result'] == 'ok' for x in parsed['rows']))
        check(f'{component}_{mode}_ids_in_full_inventory', set(x['id'] for x in parsed['rows']) <= set(inventory['ids']))
        if component == 'history':
            check(f'history_{mode}_author_log_hash', digest(FIX / filename) == author[component]['tests'][mode]['sha256'])

for review in ('history', 'signs', 'store'):
    report = read(f'review/{review}-review.json')
    check(f'{review}_cross_review_pass', report['status'] == 'PASS')
    hash_map(f'{review}_cross_review_current_sources', report['source_sha256'], REPO)
    hash_map(f'{review}_cross_review_evidence_hashes', report['evidence_sha256'], FIX)
sign_review = read('review/signs-review.json')
check('final_decoder_binding_covers_nine_sign_tests', sign_review['final_decoder_execution']['source_sha256'] == digest(REPO / 'simulations/trace_support.py')
      and sign_review['final_decoder_execution']['includes_all_nine_sign_regressions'] is True
      and sign_review['final_decoder_execution']['tests_per_mode'] == 61)
positive = [read(f'signs/positive-{m}.json') for m in ('normal', 'optimized')]
check('positive_14_cases_identical_across_modes', all(x['status'] == 'PASS' and x['case_count'] == len(x['cases']) == 14 for x in positive)
      and positive[0]['cases'] == positive[1]['cases'])
for mode in ('normal', 'optimized'):
    for phase, expected in [('before', ['verified', 'verified', 'rejected']), ('after', ['verified', 'rejected', 'rejected'])]:
        data = read(f'signs/{phase}/checks/detectors/duon-types-{mode}.json')
        check(f'{mode}_{phase}_supplied_sign_probe', [r['detector_status'] for r in data] == expected)

applications = read('applications/RESULTS.json')
check('application_report_pass', applications['status'] == 'PASS')
hash_map('applications_current_sources', applications['source_files'], REPO)
check('application_driver_hash', applications['driver_sha256'] == digest(FIX / 'run_application_checks.py'))
app_runs = {}
records = []
for mode in ('normal', 'optimized'):
    run = read(f'applications/{mode}-run.json')
    replay = read(f'applications/{mode}-replay.json')
    app_runs[mode] = run
    for action in ('run', 'replay'):
        record = read(f'applications/{mode}-{action}.execution.json')
        bindings[f'applications/{mode}-{action}.log'] = digest(FIX / f'applications/{mode}-{action}.log')
        records.append(record)
        check(f'{mode}_{action}_exit_zero', record['exit_code'] == 0)
    check(f'{mode}_application_archive_complete', run['trace']['coverage'] == replay['archive']['coverage'] == 'complete')
    check(f'{mode}_application_reports_equal_reopened', all(run[k] == replay[k] and run[k]['coverage'] == 'complete'
          for k in ('native_support', 'native_relations', 'paths')))
check('application_command_records_match', records == applications['commands'])
check('application_outcome_and_detectors_equal_between_modes', all(app_runs['normal'][k] == app_runs['optimized'][k]
      for k in ('outcome', 'native_support', 'native_relations', 'paths')))

mutations = read('admission-mutations/summary.json')
check('mutation_eight_runs_pass', mutations['all_passed'] is True and mutations['run_count'] == len(mutations['records']) == 8)
mutation_counts = []
for row in mutations['records']:
    mode = 'optimized' if row['optimized'] else 'normal'
    kind = row['mutation']
    detail = read(f'admission-mutations/{mode}-{kind}.json')
    bindings[f'admission-mutations/{mode}-{kind}.log'] = digest(FIX / f'admission-mutations/{mode}-{kind}.log')
    expected = {'baseline': 0, 'identity': 3, 'reflection': 4, 'combined': 7}[kind]
    check(f'{mode}_{kind}_mutation_record', row == detail and row['tests_run'] == 19
          and row['failure_ids'] == row['expected_failure_ids'] and len(row['failure_ids']) == expected
          and not row['error_ids'] and not row['skips'] and row['acceptance_passed'] is True
          and row['source_bytes_unchanged'] is True and row['same_producer_instance'] is True
          and row['producer_sha256'] == digest(REPO / 'simulations/vendor/aod_manual_native.py'))
    mutation_counts.append({'mode': mode, 'mutation': kind, 'tests': row['tests_run'], 'expected_failures': expected})

lint = read('aod-lint.json')
check('lint_nine_manuscripts_only', lint['status'] == 'PASS' and lint['manuscript_file_count'] == len(lint['manuscript_files']) == 9
      and set(lint['manuscript_files']) == {f['path'] for f in lint['manifest']['files']})
check('lint_digest_exit_and_manifest', lint['digest']['exit_code'] == 0 and json.loads(lint['digest']['stdout']) == lint['manifest'])
hash_map('lint_manuscript_hashes_current', {f['path']: f['sha256'] for f in lint['manifest']['files']}, REPO)
check('lint_binary_hash', lint['binary_sha256'] == digest(Path(lint['digest']['command'][0])))
check('lint_nine_strict_checks', len(lint['checks']) == 9 and all(c['exit_code'] == 0 and '--strict' in c['command']
      and json.loads(c['stdout'])['converged'] is True and json.loads(c['stdout'])['diagnostics'] == [] for c in lint['checks']))
check('lint_log_matches_result', json.loads((FIX / 'aod-lint.log').read_text()) == lint)
bindings['aod-lint.log'] = digest(FIX / 'aod-lint.log')

rebind = read('SOURCE_REBINDINGS.json')
check('rebound_vendor_current', rebind['after_sha256'] == digest(REPO / rebind['file']))
hash_map('rebound_consumers_current', {p: x['after_sha256'] for p, x in rebind['consumer_rebindings'].items()}, REPO)

failures = [c for c in checks if c['status'] == 'FAIL']
report = {'status': 'FAIL' if failures else 'PENDING' if pending else 'PASS',
          'scope': 'Independent consistency audit of existing validation and review evidence; no model/test reruns and no scientific validation.',
          'reviewer_authorship': 'Reviewer authored the R07-04 producer repair; this audit checks its recorded results and bindings, not independent correctness of that authored repair.',
          'checks_passed': len(checks)-len(failures), 'checks_failed': len(failures), 'checks': checks,
          'pending': pending, 'mismatches': failures, 'test_inventory_count': 540, 'full_suites': suite,
          'source_snapshot_files': len(before),
          'focused_tests_per_mode': {'history_including_signs': 61, 'store_execution': 42, 'signs_subset_of_history': 9},
          'focused_counts_are_not_additive': True, 'admission_mutations': mutation_counts,
          'applications': {'runs': 4, 'coverage': applications['coverage'], 'comparison_exclusions': applications['excluded_from_mode_equality'],
                           'scope': app_runs['normal']['outcome']['trace_scope']},
          'lint': {'manuscripts': lint['manuscript_files'], 'revision': lint['revision'], 'scope': lint['scope']},
          'historical_snapshot_note': 'The signs author decoder_snapshot_sha256 is intentionally an earlier snapshot. The final decoder is bound in signs-review.json, the 61-test history suite and full-suite source snapshots. Initial failed harness/guard attempts and the pre-byte-fix store logs are retained but excluded from accepted final totals.',
          'evidence_sha256': dict(sorted(bindings.items())),
          'script_sha256': digest(Path(__file__)), 'source_edits': False, 'test_or_model_reruns': False,
          'limitations': ['Complete trace coverage refers to this existing particle fixture and its inspected archives, not full proton/cavity/sensor evolution.',
                         'The GPU implementation was not executed in these full-suite runs because cuInit reports CUDA_ERROR_NO_DEVICE.',
                         'Lint covers only the nine listed Typst manuscripts; it does not validate Python/DEC/compiler semantics.']}
(FIX / 'review/final-evidence-audit.json').write_text(json.dumps(report, indent=2)+'\n')
lines = [f"Final evidence audit: {report['status']}", '',
         f"{report['checks_passed']} consistency checks pass; {len(failures)} mismatches. This is an audit of recorded execution and source bindings, not scientific validation.", '']
for mode, row in suite.items():
    lines.append(f"- {mode}: {row.get('tests_run', row.get('completed_records'))} test records; " + (f"{row['passed']} passed, {len(row['skipped'])} skipped." if row['status'] == 'PASS' else 'still running.'))
for row in suite.get('normal', {}).get('skipped', []):
    lines.append(f"- Skip: `{row['id']}` — {row['result']}.")
lines += ['', f"The source snapshot covers {len(before)} files. Focused checks record 61 history/sign tests, 42 store/execution tests and the nine-sign-test subset per mode; these counts are not additive. Eight admission mutation runs each inspect 19 cases and detect the expected 0/3/4/7 failures. Four particle run/replay commands agree on complete support/relation/path reports; timing/profile/output-directory fields are excluded from mode equality. All nine Typst lint targets pass.", '',
          report['historical_snapshot_note'], '',
          'No model or broad test rerun and no source edit were performed by this audit. Full collision evolution and independent scientific validation are outside its scope.']
if pending:
    lines += ['', 'Pending: '+', '.join(pending)+'.']
if failures:
    lines += ['', 'Mismatches: '+', '.join(c['check'] for c in failures)+'.']
(FIX / 'review/final-evidence-audit.md').write_text('\n'.join(lines)+'\n')
print(json.dumps({'status': report['status'], 'passed': report['checks_passed'], 'failed': failures, 'pending': pending}))
