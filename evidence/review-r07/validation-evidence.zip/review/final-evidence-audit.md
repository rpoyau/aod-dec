Final evidence audit: PASS

76 consistency checks pass; 0 mismatches. This is an audit of recorded execution and source bindings, not scientific validation.

- normal: 540 test records; 538 passed, 2 skipped.
- optimized: 540 test records; 538 passed, 2 skipped.
- Skip: `test_chiral_gpu.ChiralGPUTests.test_actual_gpu_matches_scalar_supplied_model` — skipped 'cuInit: CUDA_ERROR_NO_DEVICE'.
- Skip: `test_chiral_gpu.ChiralGPUTests.test_actual_gpu_preserves_uint32_thresholds_and_equality_boundary` — skipped 'cuInit: CUDA_ERROR_NO_DEVICE'.

The source snapshot covers 617 files. Focused checks record 61 history/sign tests, 42 store/execution tests and the nine-sign-test subset per mode; these counts are not additive. Eight admission mutation runs each inspect 19 cases and detect the expected 0/3/4/7 failures. Four particle run/replay commands agree on complete support/relation/path reports; timing/profile/output-directory fields are excluded from mode equality. All nine Typst lint targets pass.

The signs author decoder_snapshot_sha256 is intentionally an earlier snapshot. The final decoder is bound in signs-review.json, the 61-test history suite and full-suite source snapshots. Initial failed harness/guard attempts and the pre-byte-fix store logs are retained but excluded from accepted final totals.

No model or broad test rerun and no source edit were performed by this audit. Full collision evolution and independent scientific validation are outside its scope.
