"""Bind an independent bounded code review and its actual execution evidence."""
from pathlib import Path
import hashlib
import json

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'review'
SOURCE=Path('/home/reginaldpoyau/projects/aod/AOD_DEC_MANUAL_PATCH_2026-11-14/aod-dec')
expected={
'simulations/trace_history_union.py':'8927a67022fb7c6a8f17fd6f730310da7b769f77f0279973a154b191466de6b7',
'simulations/trace_support.py':'a1942aa88aa23844522db5538d21e51dd59469606b2f56689fa6767981eea217',
'simulations/trace_particle_relations.py':'fe604ebf9894f58b59e3f5ffe90cd9780266b98204c79606d6971ac80e91b190',
 'tests/test_trace_history_union.py':'f7e3b027348f0ea70d4579b83043461da4d3283d8645d4255a38475b6b408296'}
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
actual={p:sha(SOURCE/p) for p in expected}
if actual!=expected:raise RuntimeError('Reviewed source changed')
probes={mode:json.loads((OUT/f'history-nested-status-fixed-{mode}.json').read_text()) for mode in ['normal','optimized']}
if any(d['status']!='PASS' or d['source_sha256']!=expected for d in probes.values()):raise RuntimeError('Independent probe mismatch')
checks=[
 {'id':'HU-01','method':'code inspection against canonical _check_retained_bindings','status':'PASS','finding':'Terminal return identities bind the full trace digest; raw event identities bind vertex/cut under scope, scale and lineage.'},
 {'id':'HU-02','method':'code inspection','status':'PASS','finding':'Certificate inner waves and motif support/closure/component traces/component certificates are recursively traversed; no retained inner histories are replaced by terminal labels alone.'},
 {'id':'HU-03','method':'code inspection plus reviewed explicit regression controls','status':'PASS','finding':'Wave identity/context binds motif and every retained ordinal to its trace/certificate/motif digests. Identical overlap and shorter prefixes in either order remain compatible; replacement at an overlapping ordinal conflicts.'},
 {'id':'HU-04','method':'code inspection','status':'PASS','finding':'Positive exact binding/node budgets are enforced before growth; recursion depth is limited to64; failure is sticky, so subsequent members cannot restore a rejected/truncated union.'},
 {'id':'HU-05','method':'code inspection','status':'PASS','finding':'Support formation admission feeds the shared query union before declaring the row verified. Collection conflicts/exhaustion clear row, closure, support, window, detected form and enclosure verdicts.'},
 {'id':'HU-06','method':'code inspection','status':'PASS','finding':'Relation admission joins captured formations, reconstructed recurrent prefixes, outer fold/inner waves and contact support histories; shared prefix conflicts cannot pass via independently valid fold snapshots.'},
 {'id':'HU-07','method':'code inspection','status':'PASS','finding':'Relation union checks run after collection, reconstructed waves, folds and dependent operations; failure clears all relation categories and closure/coupling/shedding/seating axes and forces partial coverage.'},
 {'id':'HU-08','method':'code inspection','status':'PASS','finding':'Scope filtering happens after dependencies are inspected. The helper never evolves model state or modifies source witnesses; it adds consistency admission only.'},
 {'id':'HU-09','method':'independent targeted falsification, normal and optimized Python','status':'PASS','finding':'Initial rejected support union exposed verified enclosure and a detected form. Corrected conflict/binding-exhaustion/node-exhaustion controls now expose no nested verified status or detected form.'},
 {'id':'HU-10','method':'source binding','status':'PASS','finding':'All four reviewed source hashes exactly match the frozen history implementation and tests.'}]
evidence=['review/history-nested-status-counterexample.json','review/check_history_status.py','review/history-nested-status-fixed-normal.json','review/history-nested-status-fixed-optimized.json']
runtime_file=ROOT/'history/RESULTS.json'
runtime=json.loads(runtime_file.read_text()) if runtime_file.exists() else None
if runtime is not None:
 if runtime.get('status')!='PASS':raise RuntimeError('History author runtime verdict not PASS')
 if runtime.get('source_sha256')!=expected:raise RuntimeError('History execution source mismatch')
 for mode,run in runtime['tests'].items():
  if run['passed']!=61 or sha(ROOT/'history'/run['log'])!=run['sha256']:
   raise RuntimeError('History targeted test binding mismatch')
  evidence.append('history/'+run['log'])
 for execution_file in sorted((ROOT/'history').glob('*.execution.json')):
  execution=json.loads(execution_file.read_text())
  if execution.get('status')!='PASS' or execution.get('source_unchanged') is not True:
   raise RuntimeError('History probe source changed or failed')
  source=Path(execution['source']).resolve()
  for imported in execution['imported_simulations_modules'].values():
   if not Path(imported['path']).resolve().is_relative_to(source):
    raise RuntimeError('History probe has mixed imports')
  if execution_file.name.startswith('after-'):
   for name,digest in expected.items():
    if name.startswith('simulations/') and execution['source_sha256'].get(name)!=digest:
     raise RuntimeError('Final probe history source mismatch')
  evidence.append(str(execution_file.relative_to(ROOT)))
 evidence.append('history/RESULTS.json')
status='PASS' if runtime is not None else 'PASS_CODE_REVIEW_RUNTIME_PENDING'
result={'status':status,'reviewer_role':'Authored R07-02/03 store repairs; did not author or edit the reviewed R07-01 implementation. This is an independent code/provenance review, not independent scientific validation.','scope':'R07-01 retained-history union admission and downstream verdict propagation','code_verdict':'PASS','checks':checks,'unresolved_findings':[], 'resolved_findings':[{'id':'HU-X1','finding':'Rejected support union left enclosure.status verified and detected_support_form populated','evidence':'review/history-nested-status-counterexample.json','resolution':'Dependent enclosure/form verdicts are cleared and recursive hostile regression checks added; independent probe passes in both modes.'}],'source_sha256':actual,'independent_short_probes':{mode:{'status':d['status'],'cases':len(d['checks'])} for mode,d in probes.items()},'runtime_evidence':runtime if runtime is not None else 'History agent final optimized targeted/probe record pending; no completion inferred from normal-only or prior60-test logs.','evidence_sha256':{p:sha(ROOT/p) for p in evidence},'reviewed_history_source_edits_by_reviewer':False,'full_suites_rerun':False,'limits':'Query-scoped consistency of already individually admitted native witness objects; not a universal ontology proof, total-memory guarantee or full proton/cavity evolution claim.'}
(OUT/'history-review.json').write_text(json.dumps(result,indent=2)+'\n')
(OUT/'history-review.md').write_text(f'''R07-01 independent review: **{status}**. Ten code, binding and bounded falsification checks pass; no unresolved code finding remains. The reviewer authored the separate store fixes and made no edits to these history files. Multiple review agents do not supply independent scientific evidence.\n\nThe union key agrees with the native occurrence domain: scope, scale, lineage and retained event identity, with terminal trace identity separately bound. Recursion includes motif components and retained inner waves. Shared wave ordinals bind full retained prefixes while allowing legitimate shorter prefixes. Binding/node/depth limits fail closed and remain sticky. Support and relation results downgrade dependent verdicts after conflict or exhaustion.\n\nReview reproduced one intermediate defect: rejected support rows retained a verified enclosure and detected support form. The counterexample is retained; the corrected implementation clears both. Independent conflict and binding/node-exhaustion probes pass in normal and optimized Python, with no nested verified verdict.\n\n{'Final history author execution evidence is attached and hash-bound in the JSON review; no full suite was repeated by this reviewer.' if runtime is not None else 'Final history author optimized/probe evidence is still pending. This checkpoint does not infer a final runtime result from prior or normal-only logs.'}\n\nAll four reviewed files match their frozen hashes. Runtime/provenance details are bound in [history-review.json](history-review.json). Scope remains finite query consistency of already admitted witnesses; no new physical evolution or observation law is inferred.\n''')
print(json.dumps({'status':status,'checks':len(checks),'unresolved_findings':0}))
