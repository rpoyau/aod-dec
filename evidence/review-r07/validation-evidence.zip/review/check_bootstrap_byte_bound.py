"""Narrow storage review probe: SQLite TEXT character limits versus byte caps."""
from pathlib import Path
from tempfile import TemporaryDirectory
import hashlib,json,sys
REPO=Path('/home/reginaldpoyau/projects/aod/AOD_DEC_MANUAL_PATCH_2026-11-14/aod-dec')
sys.path.insert(0,str(REPO))
from simulations.trace_store import TraceStore,run_manifest,LIMITS_METADATA_POLICY,TraceError
source=REPO/'simulations/trace_store.py'
result={'probe':'bootstrap_byte_bound','source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
        'configured_bootstrap_byte_cap':LIMITS_METADATA_POLICY.max_event_bytes,'mode':'optimized' if sys.flags.optimize else 'normal'}
with TemporaryDirectory() as directory:
 with TraceStore(directory,run_manifest('review-bootstrap',source={},kernel='k',preparation='p',backend='h')) as store:
  payload='"'+'\U0001f600'*3000+'"'
  store.db.execute("UPDATE metadata SET value=? WHERE key='limits'",(payload,));store.db.commit()
  try:
   fetched=store._meta('limits',max_bytes=LIMITS_METADATA_POLICY.max_event_bytes)
   result.update(returned_characters=len(fetched),returned_utf8_bytes=len(fetched.encode('utf8')) if isinstance(fetched,str) else len(fetched))
   result['status']='COUNTEREXAMPLE' if result['returned_utf8_bytes']>LIMITS_METADATA_POLICY.max_event_bytes else 'PASS'
  except TraceError as error:
   result.update(status='PASS',read_rejection=type(error).__name__+': '+str(error))
  try:store._read_limits()
  except TraceError as error:result['final_validation_rejection']=type(error).__name__+': '+str(error)
print(json.dumps(result,indent=2))
