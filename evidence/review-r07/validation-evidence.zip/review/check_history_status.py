"""Independently check that rejected unions expose no nested verified axis."""
from pathlib import Path
import hashlib
import json
import sys

SOURCE=Path('/home/reginaldpoyau/projects/aod/AOD_DEC_MANUAL_PATCH_2026-11-14/aod-dec')
OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(SOURCE))
from tests.test_trace_history_union import SupportUnionTests, formation, shared_interior


def verified_paths(value,path='$'):
    found=[]
    if type(value) is dict:
        if value.get('status')=='verified':found.append(path)
        for key,child in value.items():found.extend(verified_paths(child,path+'.'+key))
    elif type(value) is list:
        for index,child in enumerate(value):found.extend(verified_paths(child,path+f'[{index}]'))
    return found

harness=SupportUnionTests()
left=formation();right=shared_interior(left,formation(occurrence=1,offset=100))
results=[]
for name,result in [('conflicting interior',harness.detect((left,right))),
                    ('binding budget',harness.detect((left,right),max_history_bindings=1)),
                    ('node budget',harness.detect((left,right),max_history_nodes=1))]:
    paths=verified_paths(result)
    forms=[row.get('detected_support_form') for row in result['returns']]
    good=result['coverage']=='partial' and result['observed_formations']==0 and not paths and all(value is None for value in forms)
    results.append({'case':name,'status':'PASS' if good else 'FAIL','verified_paths':paths,'support_forms':forms,
                    'coverage':result['coverage'],'history_union':result['history_union']})
mode='optimized' if sys.flags.optimize else 'normal'
files=['simulations/trace_history_union.py','simulations/trace_support.py','simulations/trace_particle_relations.py','tests/test_trace_history_union.py']
report={'status':'PASS' if all(r['status']=='PASS' for r in results) else 'FAIL','mode':mode,'checks':results,
        'source_sha256':{p:hashlib.sha256((SOURCE/p).read_bytes()).hexdigest() for p in files},
        'probe_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(OUT/f'history-nested-status-fixed-{mode}.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
if report['status']!='PASS':raise SystemExit(1)
