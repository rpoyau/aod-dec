"""Independent store/execution and source-rebinding review, without suite reruns."""
from pathlib import Path
import ast,hashlib,json,re,subprocess,sys
ROOT=Path(__file__).resolve().parents[1]
REPO=Path('/home/reginaldpoyau/projects/aod/AOD_DEC_MANUAL_PATCH_2026-11-14/aod-dec')
sys.path.insert(0,str(REPO))
from simulations.trace_store import TraceLimits,LIMITS_METADATA_POLICY
from simulations.manual_dec_fixture import source_binding
checks=[]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def read(path):return json.loads((ROOT/path).read_text())
def check(name,condition,**detail):checks.append({'name':name,'status':'PASS' if condition else 'FAIL',**detail})
def before(name):return subprocess.check_output(['git','show','9b3f5036d7d17b022558041a68332342e8f85496:'+name],cwd=REPO)
def function(tree,name):return next(n for n in ast.walk(tree) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==name)

summary=read('store/RESULTS.json')
check('reported_component_validation_passes',summary['status']=='PASS' and summary['tests_per_mode']==42)
for name,digest in summary['owned_files'].items():
 check('reviewed_source_frozen:'+name,sha(REPO/name)==digest,sha256=sha(REPO/name))
for mode in ('normal','optimized'):
 row=next(x for x in summary['tests'] if x['mode']==mode)
 log=(ROOT/'store'/f'tests-{mode}.log').read_text()
 check('recorded_tests:'+mode,row['exit_code']==0 and 'Ran 42 tests' in log and log.rstrip().endswith('OK'),log_sha256=sha(ROOT/'store'/f'tests-{mode}.log'))
 old=read(f'store/before/checks/store/independent-{mode}.json')
 new=read(f'store/after/checks/store/independent-{mode}.json')
 check('original_reopen_counterexample:'+mode,'error' in old['stored_limit_probe']['default_reopen'])
 check('reopen_reproducer_fixed:'+mode,new['stored_limit_probe']['default_reopen']==new['stored_limit_probe']['explicit_same_limits_reopen']==new['stored_limit_probe']['created'] and new['stored_limit_probe']['manifest_hash_independently_verified'] and new['stored_limit_probe']['explicit_smaller_budget']['error']=='TraceIntegrityError')
 for case in ('successful_model_checkpoint_overflow','failed_model_checkpoint_overflow'):
  check('checkpoint_reproducer:'+mode+':'+case,'error' in old[case]['traced'] and new[case]['traced']['outcome_preserved'] and new[case]['traced']['coverage']==new[case]['archive_coverage']=='partial' and new[case]['reference']['stdout_bytes']==2000)
 fixed=read(f'review/store-bootstrap-fixed-{mode}.json')
 check('independent_byte_bound_probe:'+mode,fixed['status']=='PASS' and fixed['source_sha256']==summary['owned_files']['simulations/trace_store.py'] and 'metadata exceeds read budget' in fixed['read_rejection'])

target=(REPO/'simulations/trace_execution.py').read_text();tree=ast.parse(target);old_tree=ast.parse(before('simulations/trace_execution.py'))
check('reference_execution_body_unchanged',ast.dump(function(tree,'reference'),include_attributes=False)==ast.dump(function(old_tree,'reference'),include_attributes=False))
run=function(tree,'run_core')
handlers=[n for n in ast.walk(run) if isinstance(n,ast.ExceptHandler)]
check('post_execution_handlers_are_narrow',len(handlers)==4 and all(isinstance(n.type,ast.Name) and n.type.id=='storage_errors' for n in handlers))
assignment=next(n for n in ast.walk(run) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='storage_errors' for t in n.targets))
check('no_cancellation_or_programming_exception_swallowing',ast.unparse(assignment.value)=='(TraceError, OSError, sqlite3.Error)')
check('selected_bootstrap_is_small_and_fixed',LIMITS_METADATA_POLICY.max_event_bytes==4096 and LIMITS_METADATA_POLICY.max_integer_bits==63 and LIMITS_METADATA_POLICY.max_depth==2 and LIMITS_METADATA_POLICY.max_nodes==32)
store_tree=ast.parse((REPO/'simulations/trace_store.py').read_text());init=function(store_tree,'__init__');lines=ast.unparse(init)
check('limits_selected_before_manifest',lines.index('stored_limits = self._read_limits()')<lines.index("self.manifest = json.loads(self._meta('manifest'))") and 'if read_only and limits is None:' in lines)
meta=ast.unparse(function(store_tree,'_meta'))
check('metadata_is_byte_bounded_before_utf8_decode','substr(CAST(value AS BLOB),1,?),length(CAST(value AS BLOB))' in meta and meta.index('row[1] <= max_bytes')<meta.index("row[0].decode('utf-8')"))
limits=ast.unparse(function(store_tree,'_read_limits'))
check('limits_fields_duplicate_and_exact_type_checks_preserved','object_pairs_hook=unique_fields' in limits and 'set(value) ==' in limits and 'canonical_bytes(value, LIMITS_METADATA_POLICY)' in limits and 'return TraceLimits(**value)' in limits)
post=ast.unparse(function(store_tree,'__post_init__'))
check('configuration_positive_builtin_integer_domain','type(value) is int and value > 0' in post)

binding=read('SOURCE_REBINDINGS.json');oldsha=binding['before_sha256'];newsha=binding['after_sha256']
check('vendor_rebind_before_after_match_actual_bytes',hashlib.sha256(before(binding['file'])).hexdigest()==oldsha and sha(REPO/binding['file'])==newsha)
for name,values in binding['consumer_rebindings'].items():
 old=before(name);current=(REPO/name).read_bytes()
 check('consumer_hash_binding:'+name,hashlib.sha256(old).hexdigest()==values['before_sha256'] and hashlib.sha256(current).hexdigest()==values['after_sha256'])
 if name!='simulations/manual_dec_fixture.py':
  check('consumer_change_is_digest_only:'+name,old.replace(oldsha.encode(),newsha.encode())==current)
fixture=source_binding()
check('downstream_attribution_explicit',fixture['previous_candidate_sha256']==oldsha and fixture['sha256']==newsha and fixture['local_repository']=='https://github.com/rpoyau/aod-dec' and fixture['local_path']==binding['file'] and 'upstream acceptance not inferred' in fixture['role'] and fixture['base_commit']==binding['upstream_base'])
fixture_tree=ast.parse((REPO/'simulations/manual_dec_fixture.py').read_text());guard=ast.unparse(function(fixture_tree,'source_binding'))
check('native_and_license_fingerprint_guards_remain_strict','native.require(actual == SOURCE_SHA256' in guard and 'native.require(license_digest == LICENSE_SHA256' in guard)
changed=subprocess.check_output(['git','diff','--name-only'],cwd=REPO,text=True).splitlines()
check('historical_evidence_not_overwritten',not [p for p in changed if p.startswith('evidence/')])

sources={name:sha(REPO/name) for name in [*summary['owned_files'],*binding['consumer_rebindings']]}
artifacts=['store/RESULTS.json','SOURCE_REBINDINGS.json','review/store-bootstrap-counterexample.json','review/store-bootstrap-fixed-normal.json','review/store-bootstrap-fixed-optimized.json','review/check_bootstrap_byte_bound.py']
result={'status':'PASS' if all(x['status']=='PASS' for x in checks) else 'FAIL','scope':'Independent code/evidence review of R07-02/R07-03 and root-owned source-hash rebindings. R07-04 producer code was authored by this reviewer and is excluded from an independent source-correctness verdict here.','checks_passed':sum(x['status']=='PASS' for x in checks),'checks_failed':sum(x['status']=='FAIL' for x in checks),'checks':checks,'findings':[],'resolved_findings':[{'id':'REVIEW-STORE-01','finding':'SQL TEXT length/substr admitted12002 UTF8 bytes before schema rejection under a4096-byte bootstrap cap. This remained finite but violated the claimed byte bound.','before_sha256':'942eadfda438337acc1166a97b6277674d483acff8de613e28a863e9b29a5048','resolution':'Metadata reads now cast to BLOB and bound bytes before decoding; multibyte and invalid-encoding regressions pass; independent narrow probe passes normally and under-O.','counterexample':'review/store-bootstrap-counterexample.json'}],'code_reasoning':{'outcome':'reference execution is unchanged. Completed outcome is retained across expected checkpoint, finish, detector and status storage errors. Tracing errors are separate, the first failure is retained, and unavailable durable status fields become null instead of invented counts. Missing checkpoints remain unavailable and archives stay partial.','exception_scope':'Only TraceError, OSError and sqlite3.Error are caught after model execution; BaseException and other programming/model exceptions are not swallowed. Store creation/setup errors remain outside this completion contract.','bootstrap':'A fixed4096-byte BLOB read precedes UTF8/JSON decoding. Duplicate, missing and unknown fields reject; TraceLimits validates positive exact builtin integers. Stored limits are restored only on implicit read-only reopen. Explicit caller caps remain authoritative.','rebinds':'Live consumers retain exact-hash equality guards. Five consumer/test/harness edits are digest-only; manual_dec_fixture additionally retains previous producer identity and explicitly identifies local D.E.C. downstream repair. Historical evidence is preserved.'},'source_sha256':sources,'evidence_sha256':{name:sha(ROOT/name) for name in artifacts},'suite_reruns':False,'narrow_independent_probe_runs':4,'retained_probe_reports':3,'source_edits':False,'commits':False}
(ROOT/'review/store-review.json').write_text(json.dumps(result,indent=2)+'\n')
(ROOT/'review/store-review.md').write_text(f'''Independent store/execution and root-rebinding review: **{result['status']}**, {result['checks_passed']} checks passed and {result['checks_failed']} failed. No remaining findings.

The completed result, emitted prefix and original model error survive the supplied successful/failing checkpoint-budget cases. Expected post-execution storage/trace errors are recorded separately with partial coverage; a missing checkpoint is not invented. The reference routine is unchanged, and the new handlers catch only TraceError, OSError and SQLite errors, leaving cancellation and other errors visible. Review is scoped to the stated completed-execution contract, not trace setup availability.

The first bootstrap implementation counted SQLite TEXT characters rather than bytes. An independent probe returned 12,002 UTF-8 bytes under its claimed 4,096-byte cap before schema rejection. That counterexample is retained. The corrected implementation bounds a BLOB read before UTF-8 decoding; the independent probe passes in both Python modes. Fixed configuration keys, duplicate rejection, positive exact integers and strict caller overrides remain. The component's 42 recorded tests pass per mode; this reviewer did not rerun broad suites.

All live source-rebinding hashes match before and after bytes. Strict native/license equality guards remain; consumer and mutation-harness edits are digest-only except the explicit downstream provenance fields in manual_dec_fixture. The previous Manual candidate and upstream base are retained without implying upstream modification or acceptance. This reviewer authored the separate R07-04 producer fix, so this verdict independently reviews the store/execution implementation and root-owned rebindings, not that authored producer code.

[Bound checks](store-review.json) retain code/evidence hashes and the resolved finding. No source edits or commits were made during this review.
''')
print(json.dumps({'status':result['status'],'passed':result['checks_passed'],'failed':[x for x in checks if x['status']=='FAIL']}))
