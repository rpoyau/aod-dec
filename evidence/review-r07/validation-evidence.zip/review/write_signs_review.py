"""Bind independent R07-04 admission code review to retained runtime evidence."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
SOURCE = Path('/home/reginaldpoyau/projects/aod/AOD_DEC_MANUAL_PATCH_2026-11-14/aod-dec')
EXPECTED = {
    'simulations/vendor/aod_manual_native.py': '918c6c0bd242e7ed0bff6f4d1a4ff7bf2cc840b3da41b6888c218d34eddf5be0',
    'simulations/trace_support.py': 'a1942aa88aa23844522db5538d21e51dd59469606b2f56689fa6767981eea217',
    'tests/test_duon_sign_types.py': 'ca0dd8ad94cdb65af250b913329d2c99e7263f1d5da09682185d164de7ad9847',
}

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

actual = {name: sha(SOURCE / name) for name in EXPECTED}
if actual != EXPECTED:
    raise RuntimeError('Reviewed source changed')
author = json.loads((ROOT / 'signs/RESULTS.json').read_text())
history = json.loads((ROOT / 'history/RESULTS.json').read_text())
if author['status'] != 'PASS' or history['status'] != 'PASS':
    raise RuntimeError('Author runtime evidence incomplete')
if any(EXPECTED[name] != digest for name, digest in author['owned_files'].items()):
    raise RuntimeError('Sign author source binding mismatch')
evidence = ['signs/RESULTS.json', 'history/RESULTS.json']
for name, digest in author['artifacts'].items():
    if sha(ROOT / 'signs' / name) != digest:
        raise RuntimeError('Sign artifact changed: ' + name)
    evidence.append('signs/' + name)
positives = {}
for mode in ('normal', 'optimized'):
    positive = json.loads((ROOT / 'signs' / f'positive-{mode}.json').read_text())
    if (positive['status'] != 'PASS' or positive['case_count'] != 14 or
            positive['after_source_sha256'] != EXPECTED['simulations/vendor/aod_manual_native.py'] or
            not positive['complete_route_twelve_patterns_and_list_domain_unchanged']):
        raise RuntimeError('Invalid positive control binding')
    positives[mode] = positive
    run = history['tests'][mode]
    log = ROOT / 'history' / run['log']
    if (run['passed'] != 61 or sha(log) != run['sha256'] or
            'tests.test_duon_sign_types' not in run['command']):
        raise RuntimeError('Final decoder sign regression binding mismatch')
    evidence.append('history/' + run['log'])
if positives['normal']['cases'] != positives['optimized']['cases']:
    raise RuntimeError('Positive cases differ across modes')
checks = [
    {'id': 'DS-01', 'status': 'PASS', 'method': 'independent source diff review',
     'finding': 'The native admission patch requires exact int Dion, pivot and chirality values. Python bool, float and int subclasses cannot pass by equality aliases; original finite sign domains and pivot certificate binding remain enforced.'},
    {'id': 'DS-02', 'status': 'PASS', 'method': 'independent decoder source review',
     'finding': 'The decoder normalizes built-in tuple/list containers, then checks exact integer sign domains before returning Duon or assigning any inferred core. It does not normalize scalar aliases to integers.'},
    {'id': 'DS-03', 'status': 'PASS', 'method': 'independent regression source review and bound author runs',
     'finding': 'Nine regression methods exercise producer aliases, retained motif revalidation, raw decoding and real reopened archives. Both Dion sides, both positions, ternary pivot values and chirality aliases are covered.'},
    {'id': 'DS-04', 'status': 'PASS', 'method': 'positive harness source review and bound author comparison',
     'finding': 'The comparison harness compares full canonical outputs from the baseline and modified producer, not status alone. All 14 complete-route, twelve pattern/pivot and built-in-list cases remain identical in both modes.'},
    {'id': 'DS-05', 'status': 'PASS', 'method': 'independent source and regression review',
     'finding': 'The guards are restricted to sign/chirality operands. Unrelated diagnostic Boolean metadata and the typed reflected_comparison Boolean remain valid alongside successful archive admission; no global Boolean conversion or rejection is introduced.'},
    {'id': 'DS-06', 'status': 'PASS', 'method': 'source and artifact binding',
     'finding': 'Reviewed vendor, decoder and test bytes match final frozen hashes. The early sign-only runs used an earlier decoder snapshot; final 61-test history runs in both modes include all nine sign regressions with the final decoder.'},
]
result = {
    'status': 'PASS', 'finding': 'R07-04',
    'reviewer_role': 'Authored only the separate R07-02/03 store repairs; did not author or edit these sign-admission or decoder changes. Review is code/provenance assessment, not independent scientific validation.',
    'scope': 'Exact integer Dion, pivot and chirality admission; compatible container domains and unrelated Boolean metadata.',
    'checks': checks, 'unresolved_findings': [], 'source_sha256': actual,
    'author_modes': author['modes'],
    'final_decoder_execution': {
        'source_sha256': history['source_sha256']['simulations/trace_support.py'],
        'tests_per_mode': 61, 'includes_all_nine_sign_regressions': True,
        'evidence': 'history/RESULTS.json',
    },
    'positive_cases_identical_across_modes': True,
    'evidence_sha256': {name: sha(ROOT / name) for name in evidence},
    'reviewed_sign_source_edits_by_reviewer': False,
    'full_suites_rerun': False,
    'limits': 'Finite admission and decoder checks; no claim of changed transition law, completed particle evolution or SI prediction.',
}
(ROOT / 'review/signs-review.json').write_text(json.dumps(result, indent=2) + '\n')
(ROOT / 'review/signs-review.md').write_text('''R07-04 independent admission review: **PASS**. Six code, regression and source-binding checks pass; no unresolved finding remains. The reviewer authored the separate store repair and made no edits to the sign or decoder implementation.

The native producer and consumer decoder both require exact integer sign values before admission or classification. Boolean, float and integer-subclass aliases are rejected. Built-in tuple/list construction containers, the integer sign domains and bound pivot identity remain valid. Boolean metadata outside sign operands remains supported.

Nine focused regressions pass in both modes. The final 61-test history suite includes those regressions with the final decoder, closing the earlier sign-only record's decoder snapshot difference. The independently inspected comparison harness checks full canonical producer outputs: all 14 positive cases remain unchanged before/after in normal and optimized Python.

This review binds source hashes and actual author execution evidence in [signs-review.json](signs-review.json). It does not repeat broad suites or claim new model evolution or physical predictions.
''')
print(json.dumps({'status': 'PASS', 'checks': len(checks), 'unresolved_findings': 0}))
