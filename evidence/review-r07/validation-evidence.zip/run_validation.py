"""Run standard unittest discovery on frozen R07 repairs in both modes."""
from pathlib import Path
import hashlib,json,os,re,subprocess,sys,time

ROOT=Path(__file__).resolve().parent
REPO=ROOT.parent/'AOD_DEC_MANUAL_PATCH_2026-11-14/aod-dec'
PYTHON=ROOT.parent/'AOD_M3_COMPARISON_EXECUTION_R02_2026-11-08/runtime/bin/python'
OUT=ROOT/'validation'

def source_hashes():
    files=subprocess.check_output(['git','ls-files','-z','--cached','--others','--exclude-standard'],cwd=REPO).decode().split('\0')
    return {p:hashlib.sha256((REPO/p).read_bytes()).hexdigest() for p in sorted(set(files)) if p and (REPO/p).is_file()}

def execute(name,args,timeout=2400):
    command=[str(PYTHON),*args];start=time.monotonic()
    record={'name':name,'command':command,'cwd':str(REPO),'status':'RUNNING'}
    (OUT/(name+'.execution.json')).write_text(json.dumps(record,indent=2)+'\n')
    with (OUT/(name+'.stdout.log')).open('w') as stdout,(OUT/(name+'.stderr.log')).open('w') as stderr:
        run=subprocess.run(command,cwd=REPO,stdout=stdout,stderr=stderr,timeout=timeout,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
    record.update(exit_code=run.returncode,seconds=time.monotonic()-start,status='PASS' if run.returncode==0 else 'FAIL')
    log=(OUT/(name+'.stderr.log')).read_text()
    counts=re.findall(r'^Ran (\d+) tests? in ',log,re.M)
    if counts:record['tests_run']=int(counts[-1])
    skip=re.findall(r'^OK \(skipped=(\d+)\)',log,re.M)
    record['skipped']=int(skip[-1]) if skip else 0
    if counts:record['passed']=record['tests_run']-record['skipped'] if run.returncode==0 else None
    (OUT/(name+'.execution.json')).write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record),flush=True)
    return record

def main():
    OUT.mkdir(exist_ok=True);before=source_hashes()
    (OUT/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
    rows=[]
    for name,flags in [('normal',['-B']),('optimized',['-B','-O'])]:
        rows.append(execute('unittest-'+name,[*flags,'-m','unittest','discover','-s','tests','-p','test_*.py','-v']))
    after=source_hashes();(OUT/'source-after.json').write_text(json.dumps(after,indent=2)+'\n')
    changed=[p for p in set(before)|set(after) if before.get(p)!=after.get(p)]
    result={'status':'PASS' if all(r['status']=='PASS' for r in rows) and not changed else 'FAIL','executions':rows,'source_files':len(before),'source_changes_during_validation':sorted(changed),'driver_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    (OUT/'RESULTS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
    return 0 if result['status']=='PASS' else 1
if __name__=='__main__':raise SystemExit(main())
