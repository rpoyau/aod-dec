"""Seal the completed R07 repair evidence without rewriting historical records."""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / 'AOD_DEC_MANUAL_PATCH_2026-11-14/aod-dec'
DEST = REPO / 'evidence/review-r07'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(name):
    return json.loads((ROOT / name).read_text())

def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

def main():
    validation = read('validation/RESULTS.json')
    audit = read('review/final-evidence-audit.json')
    applications = read('applications/RESULTS.json')
    lint = read('aod-lint.json')
    mutations = read('admission-mutations/summary.json')
    for name, data in [('validation', validation), ('audit', audit),
                       ('applications', applications), ('lint', lint)]:
        if data['status'] != 'PASS':
            raise SystemExit(name + ' is not PASS')
    if not mutations['all_passed']:
        raise SystemExit('mutation controls failed')
    frozen = read('validation/source-after.json')
    for rel, expected in frozen.items():
        if sha(REPO / rel) != expected:
            raise SystemExit('source changed after validation: ' + rel)
    inventory = read('validation/test-inventory.json')
    if any(row['tests_run'] != inventory['count'] for row in validation['executions']):
        raise SystemExit('test inventory mismatch')
    review_reports = {name: read('review/' + name + '-review.json')
                      for name in ('history', 'store', 'signs')}
    if any(row['status'] != 'PASS' for row in review_reports.values()):
        raise SystemExit('cross-review is not PASS')
    changed = {name: value for name, value in frozen.items()
               if read('BASELINE.json')['files'].get(name) != value}
    summary = {
        'status': 'PASS',
        'scope': 'Four R07 finite implementation corrections; no new physical evolution or calibration.',
        'reviewed_base': read('INPUT_BINDING.json')['review_source_head'],
        'input': read('INPUT_BINDING.json'),
        'findings': {
            'R07-01': 'Bounded combined history admission; conflicting or truncated unions withdraw dependent verified verdicts.',
            'R07-02': 'Checkpoint and diagnostic storage failures preserve the completed result and original model error with partial trace coverage.',
            'R07-03': 'Validated persisted limits precede implicit manifest reads; bootstrap metadata is byte bounded; explicit read limits remain authoritative.',
            'R07-04': 'Exact built-in integer Dion/pivot signs required at producer and decoder; Boolean/float/subclass aliases rejected.'
        },
        'validation': validation,
        'test_inventory_count': inventory['count'],
        'new_regressions': 29,
        'targeted_tests_per_mode': {'history_and_signs': 61, 'store_and_execution': 42, 'signs_only_subset': 9},
        'targeted_counts_overlap_full_suite': True,
        'admission_mutation_runs': mutations['run_count'],
        'admission_cases_per_run': 19,
        'aod_lint': {'revision': lint['revision'], 'status': lint['status'], 'manuscript_file_count': lint['manuscript_file_count'],
                     'scope': 'Strict lint of existing Typst manuscripts; not Python/Markdown semantics or scientific validity.'},
        'fresh_particle_run_replay': {'status': applications['status'], 'coverage': applications['coverage'],
                                      'comparison': applications['comparison']},
        'changed_tested_files': changed,
        'cross_reviews': {name: 'review/' + name + '-review.json' for name in review_reports},
        'evidence_audit': 'review/final-evidence-audit.json',
        'source_rebindings': 'SOURCE_REBINDINGS.json',
        'known_limits': ['Two current-device CUDA_ERROR_NO_DEVICE skips per full-suite mode; no new GPU execution claim.',
                        'Full proton/cavity/sensor evolution and field-generated Brownian motion remain unfinished/unverified.',
                        'No cost-inclusive speedup, M6 self-hosting or AArch64 completion claim.',
                        'Finite retained-history admission does not establish a physical scattering observable. Native tracing requires no SI conversion.',
                        'No Main/Manual source changes; the vendor repair is explicitly downstream.'],
        'evidence_policy': 'Earlier phases, counterexamples and excluded mixed-import harness records remain identified in their reports; only final source-bound runs support acceptance.'
    }
    save(ROOT / 'RESULTS.json', summary)
    DEST.mkdir(parents=True, exist_ok=False)
    for source, target in [('RESULTS.json', 'RESULTS.json'), ('SOURCE_REBINDINGS.json', 'source-rebindings.json'),
                           ('REPORT.md', 'README.md'), ('aod-lint.json', 'aod-lint.json')]:
        shutil.copyfile(ROOT / source, DEST / target)
    roots = ['history', 'store', 'signs', 'review', 'validation', 'admission-mutations', 'applications']
    members = {}
    for name in roots:
        for path in sorted((ROOT / name).rglob('*')):
            if path.is_file() and not path.is_symlink() and path.resolve().is_relative_to(ROOT):
                members[str(path.relative_to(ROOT))] = path.read_bytes()
    for name in ['INPUT_BINDING.json', 'BASELINE.json', 'SOURCE_REBINDINGS.json', 'REVIEW_INDEX.md',
                 'RESULTS.json', 'REPORT.md', 'PREFLIGHT.json', 'aod-lint.json', 'aod-lint.log',
                 'admission-initial-binding-guard.log', 'import-provenance.log', 'diff-check.log',
                 'run_validation.py', 'run_application_checks.py', 'seal_evidence.py', 'validation-driver.log']:
        members[name] = (ROOT / name).read_bytes()
    for name in ['REVIEW.md', 'FINDINGS.json', 'INPUT_BINDINGS.json', 'SOURCE_COVERAGE.json']:
        members['supplied-review/' + name] = (ROOT / 'AOD_DEC_PR6_REVIEW_R07' / name).read_bytes()
    manifest = {name: hashlib.sha256(data).hexdigest() for name, data in sorted(members.items())}
    members['SHA256SUMS'] = ''.join(value + '  ' + name + '\n' for name, value in manifest.items()).encode()
    archive = DEST / 'validation-evidence.zip'
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as out:
        for name, data in sorted(members.items()):
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 15, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            out.writestr(info, data)
    with zipfile.ZipFile(archive) as check:
        if check.testzip() is not None:
            raise SystemExit('evidence CRC failure')
        for name, expected in manifest.items():
            if hashlib.sha256(check.read(name)).hexdigest() != expected:
                raise SystemExit('evidence hash mismatch: ' + name)
    save(DEST / 'ARCHIVE.json', {'status': 'PASS', 'path': archive.name, 'sha256': sha(archive),
                               'bytes': archive.stat().st_size, 'manifest_files': len(manifest),
                               'crc_verified': True, 'manifest_verified': True})
    print(json.dumps({'status': 'PASS', 'evidence': str(DEST), 'archive_bytes': archive.stat().st_size,
                      'manifest_files': len(manifest), 'changed_tested_files': len(changed)}))

if __name__ == '__main__':
    main()
