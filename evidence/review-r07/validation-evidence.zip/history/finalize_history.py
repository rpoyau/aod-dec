from pathlib import Path
import hashlib,json,re
R=Path(__file__).resolve().parent
repo=Path('/home/reginaldpoyau/projects/aod/AOD_DEC_MANUAL_PATCH_2026-11-14/aod-dec')
owned=['simulations/trace_support.py','simulations/trace_particle_relations.py','simulations/trace_history_union.py','tests/test_trace_history_union.py']
expected=['a1942aa88aa23844522db5538d21e51dd59469606b2f56689fa6767981eea217','fe604ebf9894f58b59e3f5ffe90cd9780266b98204c79606d6971ac80e91b190','8927a67022fb7c6a8f17fd6f730310da7b769f77f0279973a154b191466de6b7','f7e3b027348f0ea70d4579b83043461da4d3283d8645d4255a38475b6b408296']
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def require(condition,message):
 if not condition:raise RuntimeError(message)
freeze={p:sha(repo/p) for p in owned}
require(list(freeze.values())==expected,'Frozen source changed')
executions=json.loads((R/'probe-executions.json').read_text())
require(len(executions)==8 and all(x['exit_code']==0 for x in executions),'Incomplete probe executions')
results=[]
for phase in ['before','after']:
 source=R.parent/'baseline' if phase=='before' else repo
 for mode in ['normal','optimized']:
  prefix=R/(phase+'-reproducer')/'checks'
  support=json.loads((prefix/'detectors'/('identity-'+mode+'.json')).read_text())
  fold=json.loads((prefix/'paths'/('fold_union_probe-'+mode+'.json')).read_text())
  require(len(support)==3,'Support controls missing')
  require([x['detector']['coverage'] for x in support]==(['complete']*3 if phase=='before' else ['partial','complete','complete']), 'Support result differs')
  require([x['detector']['observed_formations'] for x in support]==([2]*3 if phase=='before' else [0,2,2]),'Formation counts differ')
  require(all(x['producer_individual_statuses']==['verified','verified'] for x in support),'Individual admission changed')
  require('conflicting coordinates' in support[0]['producer_union_result'] and all(x['producer_union_result']=='accepted' for x in support[1:]),'Independent union controls differ')
  require(fold['baseline_coverage']==fold['real_store_coverage']=='complete','Archive/positive control incomplete')
  require(fold['real_store_detector_coverage']==fold['mutated_detector_coverage']==('complete' if phase=='before' else 'partial'),'Fold detector coverage differs')
  require((fold['mutated_fold_count'],fold['mutated_shedding_count'])==((1,4) if phase=='before' else (0,0)),'Fold dependent counts differ')
  require(fold['altered_wave_identity_unchanged'] and fold['raw_event_ids_unchanged'] and fold['scoped_lineage_unchanged'] and not fold['altered_return_identity_unchanged'],'Mutation preconditions changed')
  for name in ['identity','fold']:
   binding=json.loads((R/f'{phase}-{name}-{mode}.execution.json').read_text())
   require(binding['status']=='PASS' and binding['source_unchanged'],'Probe source changed')
   require(Path(binding['source'])==source and Path(binding['cwd'])==source,'Wrong probe source')
   require(all(Path(x['path']).is_relative_to(source) for x in binding['imported_simulations_modules'].values()),'Mixed source imports')
  results.append({'phase':phase,'mode':mode,'support_coverage':[x['detector']['coverage'] for x in support], 'formations':[x['detector']['observed_formations'] for x in support],'fold_coverage':fold['real_store_detector_coverage'],'folds':fold['mutated_fold_count'],'shedding':fold['mutated_shedding_count'],'all_imports_bound':True})
tests={}
for mode in ['normal','optimized']:
 path=R/f'targeted-final-{mode}.log';text=path.read_text()
 match=re.search(r'Ran (\d+) tests in ([0-9.]+)s\s+OK\s*$',text)
 require(match and int(match[1])==61,'Final targeted tests not complete')
 tests[mode]={'passed':int(match[1]),'seconds':float(match[2]),'log':path.name,'sha256':sha(path),'command':['/home/reginaldpoyau/projects/aod/AOD_M3_COMPARISON_EXECUTION_R02_2026-11-08/runtime/bin/python','-B']+(['-O'] if mode=='optimized' else [])+['-m','unittest','-v','tests.test_trace_support','tests.test_trace_particle_relations','tests.test_trace_history_union','tests.test_duon_sign_types']}
report={'status':'PASS','finding':'R07-01','source':str(repo),'source_sha256':freeze,'tests':tests,'new_history_regressions':12,'supplied_probe_runs':results,'scope':'Bounded consistency of the inspected retained-history collection; no transition-law changes or new physical evolution.','prefix_policy':'Identical scoped event bindings and shorter compatible wave prefixes accepted in either observation order. Conflicting event coordinates, terminal histories and overlapping wave ordinals rejected.','failure_policy':'Any history-union conflict or budget exhaustion makes the whole inspected collection partial and clears dependent verified relation/enclosure/form verdicts. Raw immutable archive remains unchanged.','limits':{'max_bindings':100000,'max_nodes':500000,'max_depth':64,'claim':'Retained union index/work limits only; not a whole-process memory bound.'},'cross_review_correction':'Cleared nested enclosure verification and detected support form on union failure; recursive hostile assertions cover conflicts and truncation after a previously valid row.','harness_correction':'Excluded provisional namespace-package mixed-import baseline attempt. Final before/after runs use separate phase-specific source symlinks and intended source cwd; every imported simulations module is path-checked and hashed.','commits':False,'remote_writes':False}
(R/'RESULTS.json').write_text(json.dumps(report,indent=2)+'\n')
(R/'REPORT.md').write_text('''R07-01 is repaired within the inspected retained-history collection. A bounded shared index checks scoped occurrence coordinates, immutable terminal digests and overlapping wave-prefix slots across support returns, motif components, recursively retained inner waves, captured carrier histories, folds and contact support. Identical shared bindings and legitimate earlier prefixes remain admissible. Conflict or budget exhaustion makes the collection partial and prevents downstream verified relation, enclosure or support-form claims; immutable archive evidence remains recoverable.

All eight supplied probe executions are source-bound. At immutable baseline 9b3f503, support conflict incorrectly returns complete/two formations, and the reopened conflicting fold archive incorrectly verifies one fold and four shedding records. In the repaired tree, those results are partial with zero verified formations/folds/shedding. The two support positive controls remain complete with two formations in both modes. Each final probe checks every imported simulations module path and its SHA-256, rejecting mixed baseline/live imports.

The final targeted suite passes 61 tests in normal Python and 61 under -O. This includes 12 new history regressions covering real reopened archives, components, nested inner waves, compatible prefixes in both orders, different overlapping ordinals, explicit index/work exhaustion, and recursive removal of verified sub-verdicts. Existing support, relation and Dion-sign tests are included.

Cross-review reproduced a nested enclosure/form verdict leak in the first patch. The final source clears those derived fields on union rejection; its counterexample is retained in the parent review directory. A provisional baseline harness imported a live relation module through a namespace-package path after preloading only the producer. That attempt is excluded in provisional-harness/DISPOSITION.json. Final phase-specific source layouts and complete import bindings replace it. The supplied review bundle is unchanged.

The exact frozen source and all final reproduction commands/results are bound in RESULTS.json and the per-run execution records. No commits, remote writes, source-provenance manifest edits or manuscript changes were made by this subtask.
''')
print(json.dumps({'status':'PASS','tests':{m:v['passed'] for m,v in tests.items()},'probe_runs':len(executions),'source_sha256':freeze}))
