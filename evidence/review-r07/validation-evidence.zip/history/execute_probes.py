from pathlib import Path
import json,subprocess,sys
ROOT=Path(__file__).resolve().parent
baseline=ROOT.parent/'baseline'
live=Path('/home/reginaldpoyau/projects/aod/AOD_DEC_MANUAL_PATCH_2026-11-14/aod-dec')
records=[]
for phase,source in [('before',baseline),('after',live)]:
 for mode in ['normal','optimized']:
  for name,relative in [('identity','detectors/probe_identity.py'),('fold','paths/fold_union_probe.py')]:
   prefix=f'{phase}-{name}-{mode}'
   probe=ROOT/(phase+'-reproducer')/'checks'/relative
   command=[sys.executable,'-B']+(['-O'] if mode=='optimized' else [])+[str(ROOT/'run_bound_probe.py'),str(probe),str(source),str(ROOT/(prefix+'.execution.json'))]
   with (ROOT/(prefix+'.log')).open('w') as f: result=subprocess.run(command,cwd=source,stdout=f,stderr=subprocess.STDOUT)
   records.append({'phase':phase,'mode':mode,'name':name,'command':command,'cwd':str(source),'exit_code':result.returncode})
   (ROOT/'probe-executions.json').write_text(json.dumps(records,indent=2)+'\n')
   if result.returncode:raise RuntimeError(prefix)
print('Eight bound reproducer runs completed')
