from pathlib import Path
import hashlib,json,runpy,sys
REPO=Path(sys.argv[2]) if len(sys.argv) > 2 else Path('/home/reginaldpoyau/projects/aod/AOD_DEC_MANUAL_PATCH_2026-11-14/aod-dec')
sys.path[:0]=[str(REPO),str(REPO/'tests')]
# Import through the real path before the immutable supplied probe inserts its
# compatibility symlink, so producer __file__ source binding stays canonical.
from simulations import proton_accounting
import test_trace_support
name=sys.argv[1]
runpy.run_path(str(Path(__file__).parent/'probes/checks'/name),run_name='__main__')
