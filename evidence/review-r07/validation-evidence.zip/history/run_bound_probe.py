"""Run an unchanged supplied probe with one canonical, path-checked source tree."""
from pathlib import Path
import hashlib,json,runpy,subprocess,sys,time
probe,source,out=map(lambda x:Path(x).resolve(),sys.argv[1:4])
if Path.cwd().resolve()!=source:raise RuntimeError('source cwd required')
sys.path[:0]=[str(source),str(source/'tests')]
files=sorted((source/'simulations').rglob('*.py'))
before={str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
# The producer binds its own __file__ relative to its resolved ROOT. Load that
# module through the canonical path before the probe adds its same-tree alias.
from simulations import proton_accounting
start=time.monotonic();runpy.run_path(str(probe),run_name='__main__')
modules={}
for name,module in sys.modules.copy().items():
 if name.startswith('simulations.') and getattr(module,'__file__',None):
  path=Path(module.__file__).resolve()
  relative=str(path.relative_to(source))  # Reject any mixed baseline/live import.
  modules[name]={'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
after={str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
if before!=after:raise RuntimeError('source changed during probe')
out.write_text(json.dumps({'status':'PASS','source':str(source),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(),'command':sys.orig_argv,'cwd':str(Path.cwd()),'probe':str(probe),'probe_sha256':hashlib.sha256(probe.read_bytes()).hexdigest(),'driver_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'elapsed_seconds':time.monotonic()-start,'source_unchanged':True,'source_sha256':before,'imported_simulations_modules':modules},indent=2)+'\n')
