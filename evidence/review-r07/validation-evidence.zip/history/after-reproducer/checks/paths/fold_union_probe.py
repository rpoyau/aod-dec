from pathlib import Path
import sys,tempfile,json
from copy import deepcopy
from dataclasses import replace
ROOT=Path(__file__).resolve().parents[2]/"source"
sys.path.insert(0,str(ROOT))
from simulations import proton_accounting as p
from simulations.vendor import aod_manual_native as n
from simulations.trace_particle_relations import detect_particle_relations,_fold,_state,_shedding
from simulations.trace_applications import NativeParticleRecorder
from simulations.trace_store import TraceStore,run_manifest
class View:
 def __init__(self,events):self.events=events
 def iter_events(self):return iter(self.events)
 def status(self):return {"coverage":"complete"}
events=[]
def capture(kind,payload):
 context=payload.get("wave",{})
 events.append({"event_id":"probe-"+str(len(events)),"kind":kind,"payload":payload,"scope_id":context.get("scope",payload.get("scope",p.SCOPE)),"lineage_id":context.get("lineage",payload.get("lineage","ancillary")),"scale_index":context.get("scale",payload.get("scale",0))})
with tempfile.TemporaryDirectory() as directory:
 with p.observe_commits(capture):p.run(Path(directory)/"proton.json")
base=detect_particle_relations(View(events))
fold_event=next(e for e in events if e["kind"]=="particle.native_fold")
f=_fold(fold_event["payload"]["fold"])
a,b=f["inner"]
old=b.returns[-1]
def swap(v):return (v & ~3)|((v&1)<<1)|((v&2)>>1)
vertices=tuple(map(swap,old.vertices))
if vertices==old.vertices:raise RuntimeError("mutation did not change coordinates")
t=replace(old,vertices=vertices)
oldm=b.motif_witnesses[-1]
m=n.motif_witness(oldm.core,t,oldm.construction,tuple(zip(oldm.component_traces,oldm.component_certificates)),{c.certificate_digest:c for c in (*oldm.component_certificates,n.certify(t))},oldm.enclosure,oldm.chirality)
traces=b.returns[:-1]+(t,)
certs=b.certificates[:-1]+(n.certify(t),)
registry={c.certificate_digest:c for c in certs}
bad=n.wave(tuple((t,c,registry) for t,c in zip(traces,certs)),b.motif_witnesses[:-1]+(m,))
union_rejected=False
try:n.field(a.scope,"joint-history",(a,b,bad))
except n.AdmissionError as exc:union_rejected=str(exc)
outer=n.outer_trace((a,bad),lineage=f["outer"][0].lineage,scope=f["outer"][0].scope,scale=f["outer"][0].scale,start_index=f["outer"][0].indices[0])
changed=n.fold((a,bad),n.certified(outer,"outer",inner=(a,bad)))
mutated=deepcopy(events)
next(e for e in mutated if e["kind"]=="particle.native_fold")["payload"]["fold"]=p.encode(changed)
for e in mutated:
 if e["kind"]!="particle.native_shedding":continue
 payload=e["payload"];r=_shedding(payload["record"])
 new=n.shedding(changed,_state(payload["source_state"]),r.closure_load,r.closure_cost,source_event_digest=r.source_event_digest,model_bridge=r.model_bridge,committed=r.committed,route=r.route,target_scope=r.target_scope,target_scale=r.target_scale)
 payload["record"]=p.encode(new)
result=detect_particle_relations(View(mutated))
with tempfile.TemporaryDirectory() as directory:
 manifest=run_manifest("fold-union-probe",source={"head":"9b3f5036d7d17b022558041a68332342e8f85496"},kernel="retained-continuation",preparation="independent-mutation",backend="host")
 with TraceStore(Path(directory)/"trace",manifest) as store:
  recorder=NativeParticleRecorder(store)
  for e in mutated:recorder(e["kind"],e["payload"])
 with TraceStore.open(Path(directory)/"trace") as store:
  stored_status=store.status()
  stored=detect_particle_relations(store)
summary={"optimized":not __debug__,"baseline_coverage":base["coverage"],"altered_wave_identity_unchanged":bad.identity==b.identity,"raw_event_ids_unchanged":t.event_ids==old.event_ids,"scoped_lineage_unchanged":(t.scope,t.scale,t.lineage)==(old.scope,old.scale,old.lineage),"altered_return_identity_unchanged":t.return_id==old.return_id,"old_vertices":old.vertices,"new_vertices":t.vertices,"direct_finite_union_rejection":union_rejected,"mutated_detector_coverage":result["coverage"],"mutated_failures":result["failures"],"mutated_fold_count":len(result["folds"]),"mutated_shedding_count":len(result["shedding"]),"real_store_coverage":stored_status["coverage"],"real_store_detector_coverage":stored["coverage"],"real_store_detector_failures":stored["failures"]}
Path(__file__).with_name("fold_union_probe-"+("optimized" if not __debug__ else "normal")+".json").write_text(json.dumps(summary,indent=2)+"\n")
print(json.dumps(summary,indent=2))
