from pathlib import Path
from dataclasses import replace, asdict
import json, sys, tempfile

ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT/'source'), str(ROOT/'source/tests')]
from test_trace_support import formation
from simulations.vendor import aod_manual_native as native
from simulations.trace_support import decode_trace, decode_motif, inspect_native_return, detect_particle_support
from simulations.trace_store import TraceStore, run_manifest

def probe(name, offset, lineage='formed'):
 a=formation(occurrence=0)
 b=formation(occurrence=1, offset=offset,lineage=lineage)
 ta=decode_trace(a['trace']);tb=decode_trace(b['trace'])
 old,new=tb.event_ids[1],ta.event_ids[1]
 tb=replace(tb,event_ids=tuple(new if x==old else x for x in tb.event_ids),
  reflection=replace(tb.reflection,outbound_ids=tuple(new if x==old else x for x in tb.reflection.outbound_ids)))
 cert=native.certify(tb)
 m=decode_motif(b['motif_witness'])
 records=tuple(zip(m.component_traces,m.component_certificates))
 registry={c.certificate_digest:c for c in (*m.component_certificates,cert)}
 motif=native.motif_witness(m.core,tb,m.construction,records,registry,m.enclosure,m.chirality)
 b.update(trace=asdict(tb),certificate=asdict(cert),motif_witness=asdict(motif))
 oracle='accepted'
 try:native.validate_record_collection((native.certified(ta),native.certified(tb)))
 except native.AdmissionError as exc:oracle=str(exc)
 with tempfile.TemporaryDirectory() as tmp:
  store=TraceStore(Path(tmp)/'trace',run_manifest('identity-probe',source={'repository':'aod-dec'},kernel='canonical-native',preparation='individually-admitted-returns',backend='host'))
  for i,p in enumerate((a,b)):
   t=p['trace'];store.append('particle.native_return',p,scope_id=t['scope'],lineage_id=t['lineage'],scale_index=t['scale'],source_ref='review-probe',source_key=str(i))
  store.finish()
  result=detect_particle_support(store)
  store.close()
  return {'case':name,'producer_individual_statuses':[inspect_native_return(p)['status'] for p in (a,b)],
   'shared_event_string':new,'bindings':[[ta.scope,ta.scale,ta.lineage,ta.vertices[1],ta.indices[1]],[tb.scope,tb.scale,tb.lineage,tb.vertices[1],tb.indices[1]]],
   'producer_union_result':oracle,'detector':result}

outputs=[probe('conflicting-same-lineage',100),probe('valid-identical-shared-event',0),probe('valid-distinct-lineage-name-reuse',100,'other')]
out=ROOT/'checks/detectors'/('identity-optimized.json' if not __debug__ else 'identity-normal.json')
out.write_text(json.dumps(outputs,indent=2)+'\n')
print(json.dumps([{'case':x['case'],'individual':x['producer_individual_statuses'],'union':x['producer_union_result'],'coverage':x['detector']['coverage'],'formations':x['detector']['observed_formations'],'errors':x['detector']['errors']} for x in outputs]))
