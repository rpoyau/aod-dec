# AOD Dec PR #6 — review R07

Reviewed 14 November 2026. [PR #6](https://github.com/rpoyau/aod-dec/pull/6): `9b3f5036d7d17b022558041a68332342e8f85496`, stacked on `5a9368f6de286cde822963bac5f8de2620f08d5f`. Target tree: `6c98af94e2e0241392a5c966e74d599aecd4779f`. Read-only review: no repository edits, commits or GitHub writes.

## Verdict

**The previous admission-test coverage finding is closed. The tracing implementation is a substantial advance, but four focused corrections remain.** The most consequential is inconsistent admission across separately retained witness families: the new support and relation detectors can verify mutually contradictory histories that the existing producer rejects as a union.

Three findings affect new tracing/replay behavior. A fourth exact-type defect is inherited from the producer and exposed by the new raw-construction detector. All supplied counterexamples reproduce normally and under optimized Python. The positive results below remain valid within their tested domains; neither passing CI nor checksummed storage establishes consistency of all scientific witness contents.

## Findings

### R07-01 — P2: validate the union of retained native histories

Affected paths: [`trace_support.py:310`](https://github.com/rpoyau/aod-dec/blob/9b3f5036d7d17b022558041a68332342e8f85496/simulations/trace_support.py#L310), and [`trace_particle_relations.py:239`](https://github.com/rpoyau/aod-dec/blob/9b3f5036d7d17b022558041a68332342e8f85496/simulations/trace_particle_relations.py#L239), especially independent fold admission at line 279.

**Support witness.** Two individually admitted `1:2:6` returns have distinct return identities but share one nonterminal event string in the same scope, scale and lineage. One binds it to vertex 1/cut 7; the other to vertex 1/cut 107. Their certificates and local formation witnesses are valid. Canonical `validate_record_collection` rejects the pair with `conflicting coordinates for immutable retained event`. The support detector instead returns complete coverage, two verified formations and no errors.

**Relation witness.** Retain the original captured right carrier, then place a separately valid altered version inside the outer fold. The altered C6 uses the same wave identity, lineage and raw event IDs, with different vertices. Rebuild the fold and dependent shedding records legitimately. Canonical finite-union admission rejects the original-plus-altered histories. The standalone relation detector still reports complete coverage, one verified fold and four shedding records with no failures. This reproduces through a freshly written, reopened, checksummed `TraceStore`; it is not a stale-envelope or synthetic-store-only result. The altered return digest/return ID changes—only the raw event IDs and wave identity remain the same.

The detector checks individual objects and some terminal bindings but does not consistently admit their combined retained histories. Storage integrity therefore succeeds while semantic identity consistency fails. The relation counterexample establishes a defect in the standalone relation query; it does not claim that every joined-path check accepts the same altered archive.

**Correction:** apply a bounded shared occurrence-binding check across inspected returns, recursively retained components/inner waves, captured carrier prefixes, folds and dependent relations. Compare overlapping retained histories while allowing legitimate earlier prefixes. Preserve identical shared bindings and the same event string in distinct lineages; both positive controls pass in the support probe. A conflict must prevent the affected collection and downstream relations from being reported as verified/complete. Budget exhaustion must remain explicit.

Evidence: `checks/detectors/probe_identity.py`, `identity-{normal,optimized}.json`; `checks/paths/fold_union_probe.py`, `fold_union_probe-{normal,optimized}.json`.

### R07-02 — P2: preserve the model outcome when checkpointing fails

Location: [`trace_execution.py:70`](https://github.com/rpoyau/aod-dec/blob/9b3f5036d7d17b022558041a68332342e8f85496/simulations/trace_execution.py#L70).

After reference execution has returned its outcome, `run_core` calls `store.checkpoint` outside the observer-failure containment. A checkpoint failure escapes the wrapper and hides the completed result or the original first model error.

Exact witness: 200 `emit 123456789` statements produce 2,000 stdout bytes. Under an allowed 2,048-byte event budget, a source ending in `out = 7` returns result `7` without tracing, but traced execution raises `TraceIncomplete: exact value exceeds serialization budget`. A source ending in `out = 1 // 0` should retain `line 203: zero divisor`; the tracing wrapper instead surfaces the checkpoint exception and returns no model outcome.

The archive correctly stays partial. This is a tracing API result/error-preservation defect, not changed model arithmetic or falsely complete storage.

**Correction:** retain the executed result, emitted prefix and original model error while reporting checkpoint failure/partial trace separately. Add both successful-source and failing-source checkpoint-budget controls. Do not mark the missing checkpoint complete.

Evidence: `checks/store/independent_probes.py`, `independent-{normal,optimized}.json`.

### R07-03 — P2: restore stored limits before reading a manifest on implicit reopen

Location: [`trace_store.py:237`](https://github.com/rpoyau/aod-dec/blob/9b3f5036d7d17b022558041a68332342e8f85496/simulations/trace_store.py#L237).

`TraceStore.open(path)` reads and validates the manifest using default limits before loading the persisted limits. A valid archive with a 270,339-byte manifest and recorded `max_event_bytes=400000` therefore fails to reopen with `metadata exceeds read budget`. Explicitly passing the original limits succeeds with complete coverage and the same chain; the manifest hash independently matches the stored checksum.

An explicit smaller reader cap correctly rejects this archive. The defect concerns the no-override route that otherwise restores stored limits automatically. Current small-manifest examples are unaffected.

**Correction:** read and validate the small limit configuration under a bounded bootstrap policy, select persisted or explicit caller limits, then read the manifest. Preserve deliberately stricter caller limits and add both reopen controls.

Evidence: the same store probe and per-mode JSON.

### R07-04 — P2: reject Boolean aliases in Dion sign construction

Locations: [`trace_support.py:99`](https://github.com/rpoyau/aod-dec/blob/9b3f5036d7d17b022558041a68332342e8f85496/simulations/trace_support.py#L99), inherited producer [`aod_manual_native.py:358`](https://github.com/rpoyau/aod-dec/blob/9b3f5036d7d17b022558041a68332342e8f85496/simulations/vendor/aod_manual_native.py#L358).

The raw-construction path recognizes Dion patterns with Python equality. `(True, -1)` compares equal to `(1, -1)`, so an otherwise admitted construction is labelled a verified Duon. The integer control `(1, -1)` verifies, while `(2, -1)` rejects. The root integration pass reproduced the Boolean acceptance, supporting the exact-type issue flagged in the component review.

This is an inherited producer edge exposed by the newly added classifier. It is separate from the successfully repaired reflection-timestamp aliases and does not reopen that regression finding. Repository instructions require exact integer/ternary operands.

**Correction:** validate the types and allowed values of construction signs before pattern matching, at the owning admission boundary and its decoding consumers. Add Boolean/float/subclass hostile controls and valid integer controls; rebind changed vendored bytes explicitly. Do not globally prohibit Boolean flags in unrelated trace metadata.

Evidence: `checks/detectors/probe_duon_types.py`, `duon-types-{normal,optimized}.json`.

## Prior feedback and supported advances

**R06-01 is closed at the reviewed source.** All 19 stable admission cases are now individual repository tests, with six positive controls and thirteen required admission rejections. Both Python modes pass. The repository mutation runner demonstrates the exact 3 identity / 4 timestamp / 7 combined failures in fresh processes, while checking the same imported producer and unchanged source bytes. The current hosted CI discovery includes all 19. The mutation runner itself is available as a separate validation command; no additional workflow edit is necessary for the original regression-discovery requirement.

The update adds substantive executable work:

- Passive core commit hooks, checksummed SQLite storage, recoverable checkpoints, bounded queries and explicit incomplete coverage. The reported checkpoint/reopen failures are specific edges within that implementation.
- Raw-return candidates distinguished from committed closures, retained start/hinge evidence, bounded alternative parses, initial phase versus reclosure counts, and separate support/coupling/shedding/seating axes. Window selection does not create a motif.
- Recorded source initialization and every one of the six source updates, including pending attempts, followed by independently admitted carrier preparation, coupling/fold, surplus, routed support, seating and receipt. Alternative windows remain nonadditive.
- A finite reduction that checks blockwise transition sums before evolving the quotient. Complete-state recurrence detection and invalidation use the declared kernel, partition, boundary/window/phase/coupling dependencies. Static boundary cancellation is not substituted for future-update sufficiency.
- Observation records keep exact native values, source/evidence dependencies, unknown discrepancy/anchor errors, shared-input interval dependence and exact covariance checks. Host profiling clocks do not become an AOD temporal anchor.
- The direct `run_regions.py` launcher is repaired. Direct/module invocation in normal/optimized Python produces identical JSON; fresh SHA-256 is `ea9dc32443a7c777140ed7e00af1be357ff9c756ff0f92ce60afc1c18bf9bc91`.

## Verification and source coverage

The review materialized **239 tracked blobs**, all matching the target Git hashes; **375 other tracked blobs** were not materialized. Operational Python/examples/native source and selected evidence were available. The complete committed binary cohort remains unavailable locally. `SOURCE_COVERAGE.json` lists every included and absent path; no older or differently hashed cohort was substituted.

The current [CI run 43647239704](https://github.com/rpoyau/aod-dec/actions/runs/43647239704) is successful. Its checked-out merge commit `4e5ad3f3661652779b092b703232278edc3a99dd` has exactly the same tree as the reviewed head. Downloaded artifacts match GitHub's SHA-256 digests and pass archive checks.

| Evidence | Normal Python | Optimized Python |
|---|---|---|
| Current hosted CI, exact 511-ID inventory | 507 passed; 4 skipped | 507 passed; 4 skipped |
| Publication validation, separately audited environment | 509 passed; 2 skipped | 509 passed; 2 skipped |
| Focused trace/reduction suites in this review | 208 passed | 208 passed |
| Integrated admission cases in this review | 19 passed | 19 passed |
| Full local suite, including unavailable prerequisites | 497 passed; 1 failure; 9 errors; 4 skipped | 497 passed; 1 failure; 9 errors; 4 skipped |

The four current CI skips are two CUDA and two NVRTC availability checks. The publication environment's two skips are CUDA device checks. They are distinct environments, not contradictory test counts. The publication normal-mode inventory is supported by retained original results, one isolated reprobe and a standard continuation; the discarded custom harness contributes no accepted coverage. Exact-ID reconciliation confirms all 511 IDs rather than inferring success from an interrupted run.

Current CI also confirms 100 source/optimization conformance cases, six malformed-IR rejections and 1,979 runtime differential cases. These are execution-conformance results, not independent physical predictions.

The local full-suite results and prerequisite failures are recorded in `checks/execution/REVIEW.md` and `full-suite-results.json`. Both local modes completed 511 tests: 497 passes, one failure, nine errors and four skips each. Nine unsuccessful native cases require unavailable pinned LLVM16; one requires the unavailable exact binary cohort. No source behavior regression is inferred from those environment failures, and this review does not describe the local full suite as green.

Independent finite arithmetic checks pass in both modes: 1,080 kernel/partition decisions, 14,364 later fine/quotient updates, 81 cycles with 2,835 later cache queries, 729 covariance matrices and 81 norm enclosures. A small five-mode profile campaign completes 25 workloads; a separate resource driver stops at 16/64/256 retained transitions, retains partial checkpoints and discards zero required witnesses. These finite checks do not establish a universal memory or speedup bound.

## Scope of the requested tracing work

The recovered trace/profile request was compared with its published implementation and later corrections. Historical acceptance records explicitly identify partial breadth in higher-scale execution, comprehensive memory/cost campaigns and live collision/cavity evolution. Their old TP-27 explanation requiring a Tau recipe is superseded by the published classification correction.

**A Tau label or desired motif is not a required input.** The experiment needs declared collision populations, cavity/sensor preparation and their executable evolution. The current runner evolves its `1:2` source and then maps that history into admitted `3:3` carriers; it does not yet evolve the full proton/cavity/sensor population together. Generic structural detection and path tracing are useful without claiming that missing experiment has run.

Likewise, the finite quotient demonstration establishes its specified mathematical update relation. It does not supply higher-octave AOD dynamics or a Sun–Mercury trajectory. Existing Manual mappings are retained; these tests do not independently authenticate a new SI-second or hyperfine prediction. Native AOT/ORC outputs are checked separately from host commit tracing; no full native trace transport, whole-region compilation, self-hosting or new cost-inclusive speedup follows.

## Delivery

The bundle contains this integrated review, component reports, executable counterexamples, exact outputs, admission mutation results, test/CI inventory audits, source coverage and selected CI/publication archives. Reproduction starts in `REVIEW_INDEX.md`. The proposed corrections have not been applied.
