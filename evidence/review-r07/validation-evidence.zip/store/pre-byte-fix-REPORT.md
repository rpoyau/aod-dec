R07-02 and R07-03 are repaired; supplied probes reproduce before the fix and pass their intended contracts after the fix, normally and under optimized Python.

The completed model result, emitted prefix and first model error survive checkpoint budget/storage failure. Trace finalization and diagnostic failures remain explicit, with partial coverage and null unavailable counts/measurements. A missing checkpoint is never attested complete. The forced disk-measurement control covers a durable checkpoint followed by repeated status failure; a separate control covers failed finish and detection.

Implicit read-only reopening validates limits under a fixed 4 KiB bootstrap before reading the manifest with restored limits. Configurations require the exact six positive-integer fields and reject duplicates and malformed/oversized values. Explicit reader policies remain authoritative. The 270,339-byte manifest reopens with its stored 400,000-byte cap and identical chain; a stricter cap rejects. Configuration integers are bounded to the signed SQLite domain; metadata traversal is separately bounded.

All 41 store/execution tests pass in each mode, including seven new regression tests. Probe copies and supplied input remain byte-identical; source hashes and exact commands are in RESULTS.json. No source manifest edits, commits or remote writes were performed by this agent.
