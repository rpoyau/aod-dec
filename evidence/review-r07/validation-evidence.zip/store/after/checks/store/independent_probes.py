"""Bounded storage and passive execution counterexamples for PR6.

All writes occur in fresh temporary trace directories. Repository code is read
without edits. This script reports observed contract gaps, not passing tests.
"""
from pathlib import Path
import hashlib
import json
import sqlite3
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'source'))
from simulations.trace_store import TraceStore, TraceLimits, run_manifest
from simulations.trace_execution import run_core, reference


def stored_limit_probe():
    result = {}
    with tempfile.TemporaryDirectory() as directory:
        limits = TraceLimits(max_event_bytes=400000, max_storage_bytes=4*1024*1024)
        manifest = run_manifest('large-manifest', source={'digest':'a'*64},
            kernel='declared', preparation={'bytes':'x'*270000})
        with TraceStore(directory, manifest, limits=limits) as store:
            store.append('raw', {'n':1}, scope_id='S', lineage_id='L', source_ref='review')
            store.finish()
            result['created'] = store.verify()
        with sqlite3.connect(str(Path(directory)/'trace.sqlite3')) as db:
            data = dict(db.execute('SELECT key,value FROM metadata'))
            result['manifest_bytes'] = len(data['manifest'])
            result['stored_max_event_bytes'] = json.loads(data['limits'])['max_event_bytes']
            result['manifest_hash_independently_verified'] = hashlib.sha256(data['manifest'].encode()).hexdigest() == data['manifest_hash']
        try:
            with TraceStore.open(directory) as store:
                result['default_reopen'] = store.verify()
        except Exception as exc:
            result['default_reopen'] = {'error':type(exc).__name__, 'message':str(exc)}
        with TraceStore.open(directory, limits=limits) as store:
            result['explicit_same_limits_reopen'] = store.verify()
        try:
            with TraceStore.open(directory, limits=TraceLimits(max_event_bytes=2048)):
                result['explicit_smaller_budget'] = 'accepted'
        except Exception as exc:
            result['explicit_smaller_budget'] = {'error':type(exc).__name__, 'message':str(exc)}
    return result


def passive_outcome_probe(final_statement):
    source = ('Dec main() -> out:\n    () -> int out:\n' +
              '        emit 123456789\n'*200 + '        '+final_statement+'\n')
    expected = reference(source)
    record = {'reference': {'result':expected['result'], 'error':expected['error'],
                           'exit_code':expected['exit_code'], 'stdout_bytes':len(expected['stdout']),
                           'stdout_sha256':hashlib.sha256(expected['stdout'].encode()).hexdigest()}}
    with tempfile.TemporaryDirectory() as directory:
        path = Path(directory)/'trace'
        try:
            result = run_core(source, path, limits=TraceLimits(max_event_bytes=2048))
            record['traced'] = {'outcome_preserved':result['outcome']==expected,
                                'coverage':result['trace']['coverage']}
        except Exception as exc:
            record['traced'] = {'error':type(exc).__name__, 'message':str(exc),
                                'outcome_returned':False}
        with TraceStore.open(path) as store:
            record['archive_coverage'] = store.status()['coverage']
    return record


report = {'head':'9b3f5036d7d17b022558041a68332342e8f85496', 'optimized':not __debug__,
          'stored_limit_probe':stored_limit_probe(),
          'successful_model_checkpoint_overflow':passive_outcome_probe('out = 7'),
          'failed_model_checkpoint_overflow':passive_outcome_probe('out = 1 // 0')}
destination = Path(__file__).with_name('independent-' + ('optimized' if not __debug__ else 'normal') + '.json')
destination.write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps(report, indent=2))
