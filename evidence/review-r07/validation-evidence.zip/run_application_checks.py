from pathlib import Path
import hashlib,json,os,subprocess,time
R=Path(__file__).resolve().parent
REPO=R.parent/'AOD_DEC_MANUAL_PATCH_2026-11-14/aod-dec'
PY=R.parent/'AOD_M3_COMPARISON_EXECUTION_R02_2026-11-08/runtime/bin/python'
OUT=R/'applications'

def run(name,flags,args):
    command=[str(PY),'-B',*flags,*args];start=time.monotonic()
    with (OUT/(name+'.log')).open('w') as log:
        result=subprocess.run(command,cwd=REPO,stdout=log,stderr=subprocess.STDOUT,timeout=600,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
    row={'command':command,'cwd':str(REPO),'exit_code':result.returncode,'seconds':time.monotonic()-start}
    (OUT/(name+'.execution.json')).write_text(json.dumps(row,indent=2)+'\n')
    if result.returncode:raise RuntimeError(name)
    return row

def main():
    OUT.mkdir(exist_ok=True);rows=[];results={};replays={}
    for mode,flags in [('normal',[]),('optimized',['-O'])]:
        trace=OUT/(mode+'-trace');output=OUT/(mode+'-run.json');replay=OUT/(mode+'-replay.json')
        rows.append(run(mode+'-run',flags,['scripts/trace_simulation.py','run','--example','particles','--trace',str(trace),'--output',str(output)]))
        rows.append(run(mode+'-replay',flags,['scripts/trace_simulation.py','replay',str(trace),'--output',str(replay)]))
        results[mode]=json.loads(output.read_text());replays[mode]=json.loads(replay.read_text())
        if results[mode]['trace']['coverage']!='complete' or replays[mode]['archive']['coverage']!='complete':raise RuntimeError('archive partial')
        for key in ('native_support','native_relations','paths'):
            if results[mode][key]['coverage']!='complete' or replays[mode][key]['coverage']!='complete':raise RuntimeError(mode+' '+key+' partial')
            if results[mode][key]!=replays[mode][key]:raise RuntimeError(mode+' live/replay '+key)
    for key in ('outcome','native_support','native_relations','paths'):
        if results['normal'][key]!=results['optimized'][key]:raise RuntimeError('mode difference: '+key)
    report={'status':'PASS','commands':rows,'comparison':'Complete live/reopened support, relation and path reports agree per mode; scientific outcome and all three detector reports agree between modes. Host trace/profile metrics and external output directory are excluded.','excluded_from_mode_equality':['trace','profile','external_application_artifacts'],'coverage':{m:{k:results[m][k]['coverage'] for k in ('native_support','native_relations','paths')} for m in results},'source_files':{str(p.relative_to(REPO)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((REPO/'simulations').rglob('*.py'))},'driver_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    (OUT/'RESULTS.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':'PASS','coverage':report['coverage']}),flush=True)
if __name__=='__main__':main()
