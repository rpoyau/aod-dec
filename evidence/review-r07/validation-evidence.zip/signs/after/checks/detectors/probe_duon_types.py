from pathlib import Path
from dataclasses import asdict
from copy import deepcopy
import json,sys
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'source'))
from simulations.vendor import aod_manual_native as n
from simulations.collision_routing import _route_support
from simulations.trace_support import inspect_native_return

wave=_route_support(n.recurrent('source',n=2),'route-test',20)['wave']
motif=asdict(wave.motif_witnesses[0])
base={'trace':asdict(wave.returns[0]),'certificate':asdict(wave.certificates[0]),
      'formation':{k:motif[k] for k in ('construction','component_traces','component_certificates')}}
rows=[]
for label,value in [('integer-sign',1),('boolean-sign',True),('invalid-integer-sign',2)]:
 p=deepcopy(base);c=p['formation']['construction'];p['formation']['construction']=((value,-1),c[1],c[2])
 r=inspect_native_return(p)
 rows.append({'case':label,'construction':p['formation']['construction'],'detector_status':r['status'],'signature':r['signature'],'reason':r['reason']})
out=ROOT/'checks/detectors'/('duon-types-optimized.json' if not __debug__ else 'duon-types-normal.json')
out.write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows))
