"""Compare complete valid route/witness bytes against the reviewed old producer."""
from dataclasses import asdict,is_dataclass
from pathlib import Path
from unittest.mock import patch
import hashlib,importlib.util,json,subprocess,sys

ROOT=Path(__file__).resolve().parent
REPO=Path('/home/reginaldpoyau/projects/aod/AOD_DEC_MANUAL_PATCH_2026-11-14/aod-dec')
sys.path.insert(0,str(REPO))
from simulations import collision_routing as routing
from simulations.vendor import aod_manual_native as current

def plain(value):
    if is_dataclass(value):return plain(asdict(value))
    if type(value) is dict:return {k:plain(v) for k,v in value.items()}
    if type(value) in (tuple,list):return [plain(x) for x in value]
    return value

def canonical(value):return json.dumps(plain(value),sort_keys=True,separators=(',',':'))

def cases(producer):
    with patch.object(routing,'native',producer):
        source=producer.recurrent('source',n=2)
        route=routing._route_support(source,'sign-positive-control',20)
        records=[{'case':'complete-route-support','value':canonical(route)}]
        motif=route['wave'].motif_witnesses[0]
        registry={c.certificate_digest:c for c in (*motif.component_certificates,motif.closure)}
        pivot_id=motif.construction[1][0]
        for left in ((1,-1),(-1,1)):
            for right in ((1,-1),(-1,1)):
                for state in (-1,0,1):
                    made=producer.motif_witness('Duon',motif.support_trace,
                        (left,(pivot_id,state),right),
                        tuple(zip(motif.component_traces,motif.component_certificates)),
                        registry,motif.enclosure,motif.chirality)
                    producer.validate_motif(made)
                    records.append({'case':repr((left,right,state)),'value':canonical(made)})
        listed=producer.motif_witness('Duon',motif.support_trace,
            tuple(list(part) for part in motif.construction),
            tuple(zip(motif.component_traces,motif.component_certificates)),
            registry,motif.enclosure,motif.chirality)
        producer.validate_motif(listed)
        records.append({'case':'existing-list-pattern-domain','value':canonical(listed)})
    return records

old_path=ROOT/'reviewed-producer.py'
old_source=subprocess.check_output(['git','show','9b3f5036d7d17b022558041a68332342e8f85496:simulations/vendor/aod_manual_native.py'],cwd=REPO)
old_path.write_bytes(old_source)
if hashlib.sha256(old_source).hexdigest()!='562b3eb53ad6dd13c0801c43bd6e918110083ab4d12592c024b3007b634e2554':
    raise RuntimeError('incorrect baseline producer')
spec=importlib.util.spec_from_file_location('reviewed_sign_producer',old_path)
old=importlib.util.module_from_spec(spec);sys.modules[spec.name]=old;spec.loader.exec_module(old)
before=cases(old);after=cases(current)
if before!=after:raise RuntimeError('valid construction or full route changed')
mode='optimized' if sys.flags.optimize else 'normal'
result={'status':'PASS','mode':mode,'case_count':len(before),
        'complete_route_twelve_patterns_and_list_domain_unchanged':True,
        'before_source_sha256':hashlib.sha256(old_source).hexdigest(),
        'after_source_sha256':hashlib.sha256(Path(current.__file__).read_bytes()).hexdigest(),
        'runner_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'cases':[{'case':row['case'],'canonical_sha256':hashlib.sha256(row['value'].encode()).hexdigest()} for row in before]}
(ROOT/f'positive-{mode}.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'mode':mode,'cases':len(before)}))
