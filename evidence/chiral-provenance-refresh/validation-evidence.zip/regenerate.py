"""Regenerate the exact CI canonical exemplar and retain before/after checks."""
from pathlib import Path
import argparse
import difflib
import hashlib
import json
import subprocess
import sys

OUT = Path(__file__).resolve().parent
REPO = OUT.parent / 'AOD_DEC_MANUAL_PATCH_2026-11-14/aod-dec'
sys.path.insert(0, str(REPO))
from scripts.simulate_chiral_collision import configs, native_replay
from simulations.chiral_collision import common_ticket_denominator, simulate_path
from simulations.chiral_dec import dec_source, validate_native_output

def digest(data):
    return hashlib.sha256(data).hexdigest()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--write', action='store_true')
    args = parser.parse_args()
    mode = 'normal' if __debug__ else 'optimized'
    baseline = subprocess.check_output(['git', 'show', 'f1edabcaf2dcb1ffe9009a3075018155d2a5ac1b:examples/chiral_core_collision.dec'], cwd=REPO)
    target = REPO / 'examples/chiral_core_collision.dec'
    cases = configs()
    denominator = common_ticket_denominator([cases[name] for name in ('core_only', 'uniform', 'contact_feedback')])
    path = simulate_path(cases['core_only'], seed=7, ticket_denominator=denominator)
    generated = dec_source(cases['core_only'], path).encode()
    before, after = baseline.decode().splitlines(keepends=True), generated.decode().splitlines(keepends=True)
    changed = [i + 1 for i, (a, b) in enumerate(zip(before, after)) if a != b]
    if len(before) != len(after) or changed != [6, 8]:
        raise SystemExit('Unexpected generated delta: ' + repr(changed))
    statements = lambda lines: ''.join(line for line in lines if not line.lstrip().startswith('#')).encode()
    if statements(before) != statements(after):
        raise SystemExit('Executable statements changed')
    reproduced = None
    if args.write:
        if target.read_bytes() != baseline:
            raise SystemExit('Canonical example no longer matches reviewed baseline')
        try:
            native_replay(OUT / 'before-replay', {'core_only-7': path}, False, [])
        except ArithmeticError as error:
            reproduced = str(error)
        if reproduced != 'published canonical Dec example differs from generated replay':
            raise SystemExit('Expected original CI failure was not reproduced')
        target.write_bytes(generated)
    if target.read_bytes() != generated:
        raise SystemExit('Published example does not exactly match generator')
    (OUT / 'before.dec').write_bytes(baseline)
    (OUT / 'after.dec').write_bytes(generated)
    (OUT / 'example.diff').write_text(''.join(difflib.unified_diff(before, after, fromfile='f1edabc', tofile='regenerated')))
    executions = []
    outputs = []
    for phase in ('before', 'after'):
        command = [sys.executable, '-B'] + (['-O'] if not __debug__ else []) + [str(REPO / 'aodc.py'), 'run', str(OUT / (phase + '.dec'))]
        run = subprocess.run(command, cwd=REPO, capture_output=True)
        (OUT / (phase + '-' + mode + '.stdout')).write_bytes(run.stdout)
        (OUT / (phase + '-' + mode + '.stderr')).write_bytes(run.stderr)
        if run.returncode:
            raise SystemExit('VM execution failed: ' + run.stderr.decode())
        validate_native_output(run.stdout.decode(), path)
        outputs.append(run.stdout)
        executions.append({'phase': phase, 'command': command, 'exit_code': run.returncode, 'stdout_sha256': digest(run.stdout)})
    if outputs[0] != outputs[1]:
        raise SystemExit('VM output changed')
    commands = []
    replay = native_replay(OUT / ('replay-' + mode), {'core_only-7': path}, False, commands)
    report = {'status': 'PASS', 'baseline': 'f1edabcaf2dcb1ffe9009a3075018155d2a5ac1b', 'mode': mode,
              'canonical_case': 'core_only-7', 'ticket_denominator': denominator, 'changed_lines': changed,
              'before_sha256': digest(baseline), 'after_sha256': digest(generated),
              'executable_statements_sha256': digest(statements(before)), 'vm_stdout_identical': True,
              'original_ci_failure_reproduced': reproduced, 'executions': executions,
              'native_replay_guard_and_vm_replay': replay, 'replay_commands': commands,
              'driver_sha256': digest(Path(__file__).read_bytes()),
              'source_sha256': {name: digest((REPO / name).read_bytes()) for name in
                               ['simulations/chiral_dec.py', 'simulations/chiral_collision.py',
                                'simulations/manual_dec_fixture.py', 'simulations/vendor/aod_manual_native.py',
                                'scripts/simulate_chiral_collision.py']}}
    (OUT / ('regeneration-' + mode + '.json')).write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({key: report[key] for key in ('status', 'mode', 'changed_lines', 'vm_stdout_identical', 'after_sha256')}))

if __name__ == '__main__':
    main()
