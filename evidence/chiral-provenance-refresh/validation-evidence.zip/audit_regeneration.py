"""Independent read-only audit of the narrow canonical provenance repair."""
from pathlib import Path
import hashlib
import json
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / 'AOD_DEC_MANUAL_PATCH_2026-11-14/aod-dec'
BASE = 'f1edabcaf2dcb1ffe9009a3075018155d2a5ac1b'
NAME = 'examples/chiral_core_collision.dec'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def main():
    checks = []
    def check(name, condition):
        checks.append({'name': name, 'passed': bool(condition)})
    before = subprocess.check_output(['git', 'show', BASE + ':' + NAME], cwd=REPO)
    after = (REPO / NAME).read_bytes()
    a, b = before.splitlines(keepends=True), after.splitlines(keepends=True)
    changed = [n + 1 for n, (old, new) in enumerate(zip(a, b)) if old != new]
    check('exactly retained-path and producer header lines changed', len(a) == len(b) and changed == [6, 8])
    check('all executable statements and other comments unchanged',
          all(x == y for n, (x, y) in enumerate(zip(a, b), 1) if n not in (6, 8)))
    check('before artifact bound to Git reviewed head', (ROOT / 'before.dec').read_bytes() == before)
    check('after artifact bound to current canonical file', (ROOT / 'after.dec').read_bytes() == after)
    producer = digest((REPO / 'simulations/vendor/aod_manual_native.py').read_bytes())
    check('producer header binds actual current bytes', b[7].decode().strip() == '# Manual producer SHA-256: ' + producer)
    evidence = {}
    source = {NAME: digest(after)}
    stdout = []
    for mode in ('normal', 'optimized'):
        name = 'regeneration-' + mode + '.json'
        report = json.loads((ROOT / name).read_text())
        evidence[name] = digest((ROOT / name).read_bytes())
        check(mode + ' report has correct case and inputs', report['status'] == 'PASS' and
              report['baseline'] == BASE and report['canonical_case'] == 'core_only-7' and
              report['ticket_denominator'] == 64 and report['changed_lines'] == [6, 8])
        check(mode + ' report artifact hashes match', report['before_sha256'] == digest(before)
              and report['after_sha256'] == digest(after))
        check(mode + ' driver hash matches inspected harness', report['driver_sha256'] == digest((ROOT / 'regenerate.py').read_bytes()))
        for rel, expected in report['source_sha256'].items():
            actual = digest((REPO / rel).read_bytes())
            source[rel] = actual
            old = subprocess.check_output(['git', 'show', BASE + ':' + rel], cwd=REPO)
            check(mode + ' source unchanged and bound: ' + rel, actual == expected == digest(old))
        for item in report['executions']:
            rel = item['phase'] + '-' + mode + '.stdout'
            raw = (ROOT / rel).read_bytes()
            stdout.append(raw)
            evidence[rel] = digest(raw)
            check(rel + ' actual output hash and successful exit', digest(raw) == item['stdout_sha256'] and item['exit_code'] == 0)
            check(rel + ' interpreter mode is explicit', ('-O' in item['command']) == (mode == 'optimized'))
            check(rel + ' stderr empty', not (ROOT / (item['phase'] + '-' + mode + '.stderr')).read_bytes())
        replay = report['native_replay_guard_and_vm_replay']
        check(mode + ' actual canonical gate and source/IR replay succeeded', replay['status'] == 'PASS' and
              replay['native_requested'] is False and all(r['status'] == 'PASS' and r['returncode'] == 0 for r in report['replay_commands']))
        for rel, expected in replay['artifact_sha256'].items():
            artifact = ROOT / ('replay-' + mode) / rel
            evidence[str(artifact.relative_to(ROOT))] = digest(artifact.read_bytes())
            check(mode + ' replay artifact hash: ' + rel, digest(artifact.read_bytes()) == expected)
    check('all four before/after normal/optimized VM outputs identical', len(set(stdout)) == 1)
    normal = json.loads((ROOT / 'regeneration-normal.json').read_text())
    check('original CI guard failure explicitly reproduced before repair',
          normal['original_ci_failure_reproduced'] == 'published canonical Dec example differs from generated replay')
    evidence['regenerate.py'] = digest((ROOT / 'regenerate.py').read_bytes())
    evidence['audit_regeneration.py'] = digest(Path(__file__).read_bytes())
    report = {'status': 'PASS' if all(c['passed'] for c in checks) else 'FAIL',
              'scope': 'Independent source/evidence review of two provenance-header changes, not a scientific or full-workflow acceptance claim.',
              'baseline': BASE, 'reviewer_source_edits': False, 'reviewer_model_or_test_reruns': False,
              'checks': checks, 'checks_passed': sum(c['passed'] for c in checks),
              'changed_lines': changed, 'source_sha256': source, 'evidence_sha256': evidence,
              'findings': [],
              'generation_inputs': 'configs()[core_only], seed 7, shared ticket denominator 64; default CollisionConfig contact gain would be wrong.',
              'other_active_artifacts': 'Only this active example retains the previous producer hash. Cell example binds its unchanged jitter schedule; routing compares historical cohort bytes to their own retained artifact binding. Historical evidence should not be regenerated.',
              'limits': ['Full GitHub workflow remains a separate required acceptance check.',
                         'native_replay is invoked in both parent modes, but its CLI children use plain sys.executable in both runs; the separate before/after VM commands explicitly exercise normal and -O.',
                         'No new native AOT/JIT execution is claimed by this focused evidence.']}
    (ROOT / 'review.json').write_text(json.dumps(report, indent=2) + '\n')
    (ROOT / 'review.md').write_text(
        'Independent review: **' + report['status'] + '**, ' + str(report['checks_passed']) + ' checks. '
        'The repair changes only lines 6 and 8 of the canonical chiral example, rebinding the retained path and actual producer bytes. '
        'All executable statements, other comments and all four before/after normal/optimized VM outputs remain identical. '
        'The inspected regeneration harness uses the CI core-only case, seed 7 and shared denominator 64; source/IR replay passes the original canonical equality gate.\n\n'
        'The generator, model evaluator, producer, binding adapter and CI study runner remain identical to f1edabc. '
        'The original CI guard failure is retained as a normal-mode pre-repair reproduction. '
        'The existing native_replay helper launches plain-Python CLI children in both parent modes; explicit before/after VM invocations separately exercise -O. '
        'No new AOT/JIT execution or completed GitHub workflow is inferred from these focused checks.\n\n'
        'Search of active source/examples found no second artifact carrying the old producer hash. '
        'The cell example binds an unchanged jitter schedule, and later routing checks historical cohort bytes against their own preserved binding. '
        'Historical evidence should remain unchanged. Full-workflow completion and checksum publication are the parent task’s remaining acceptance steps. '
        'No source edits or model/test reruns were performed by this reviewer. Exact source and evidence hashes are retained in review.json.\n')
    print(json.dumps({'status': report['status'], 'checks_passed': report['checks_passed'], 'findings': report['findings']}))

if __name__ == '__main__':
    main()
