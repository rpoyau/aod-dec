"""Integrate completed validation records without rerunning tests."""
from pathlib import Path
import hashlib
import json
import re
import subprocess

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent / 'aod-dec'
WORK = OUT.parent.parent


def read(name):
    return json.loads((OUT / name).read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def parse_log(name):
    rows=[]
    current=None
    for line in (OUT/name).read_text().splitlines():
        match=re.match(r'^\S+ \(([^)]+)\)(?: \.\.\.(.*))?$',line)
        if match:current=match.group(1);tail=(match.group(2) or '').strip()
        else:tail=line.strip()
        if current and ' ... ' in tail:
            tail=tail.rsplit(' ... ',1)[-1]
        if current and (tail=='ok' or tail.startswith('skipped ') or tail in ('FAIL','ERROR')):
            rows.append({'test':current,'status':'PASS' if tail=='ok' else 'SKIP' if tail.startswith('skipped ') else tail,
                         'reason':tail if tail!='ok' else None,'evidence':name})
            current=None
    return rows

all_prior=parse_log('unittest-normal.stderr.log')+parse_log('concurrent-reprobe.stderr.log')
selected_prior=set(read('normal-completed-ids.json'))
prior=[row for row in all_prior if row['test'] in selected_prior]
repeated_prior=[row for row in all_prior if row['test'] not in selected_prior]
remaining=parse_log('standard-normal-remaining.stderr.log')
optimized=parse_log('standard-optimized.stderr.log')
normal = prior + remaining
inventory = read('normal-resume-harness-aborted.inventory.json')
if len({r['test'] for r in normal}) != len(normal):
    raise RuntimeError('Duplicate coverage in resumed normal inventory')
if {r['test'] for r in normal} != {r['test'] for r in optimized}:
    raise RuntimeError('Normal and optimized inventories differ')
if len(normal) != inventory['total_discovered']:
    raise RuntimeError('Normal inventory incomplete')
for name in ['normal-remaining', 'optimized']:
    if read('standard-'+name+'.execution.json')['status'] != 'PASS':
        raise RuntimeError(name+' test failures')
summary = {}
for mode, rows in [('normal',normal),('optimized',optimized)]:
    summary[mode] = {'tests':len(rows), 'passed':sum(r['status']=='PASS' for r in rows),
                     'skipped':[r for r in rows if r['status']=='SKIP'],
                     'failed':[r for r in rows if r['status'] in ('FAIL','ERROR')]}
    write(mode+'-all-test-results.json',rows)
before=read('source-before.json')
after={p:sha(ROOT/p) for p in before}
changed=[p for p in before if before[p]!=after[p]]
write('source-after.json',after)
lint=read('aod-lint.json')
comparison=read('comparison-audit.json')
commands=[read(f'{name}.execution.json') for name in ['aod-lint','regions-direct-normal','regions-module-normal','regions-direct-optimized','regions-module-optimized','concurrent-reprobe']]
commands.extend(read('standard-'+mode+'.execution.json') for mode in ['normal-remaining','optimized'])
tools={}
for name,path in [('aod_skill','AOD_DEC_PR_2026-11-13/tools/aod-skills/skills/aod/SKILL.md'),
                  ('af_skill','AOD_DEC_PR_2026-11-13/tools/aod-skills/skills/axiomatic-fundamentalism/SKILL.md')]:
    tools[name]={'path':str(WORK/path),'sha256':sha(WORK/path)}
result={'status':'PASS' if not changed and lint['status']=='PASS' and comparison['status']=='PASS' and not any(summary[m]['failed'] for m in summary) else 'FAIL',
        'scope':'Actual direct/module region launch, full existing Python test inventory, pinned manuscript lint and bounded import-bootstrap review.',
        'tests':summary,'normal_resume':{'interrupted':read('interruption.json'),'discarded_custom_harness_attempt':read('resume-harness-interruption.json'),'completed_before_resume':len(prior),'completed_after_resume':len(remaining),'docstring_cases_repeated_due_initial_log_parser':repeated_prior,'fresh_concurrent_reprobe':read('concurrent-reprobe.execution.json')},
        'mode_coverage_identical':True,'launch_comparison':comparison,'aod_lint':{'status':lint['status'],'manuscripts':lint['manuscript_file_count'],'files':lint['manuscript_files'],'revision':lint['revision'],'binary_sha256':lint['binary_sha256'],'scope':lint['scope']},
        'commands':commands,'source_files':len(before),'source_changed':changed,'guidance':tools,
        'source_edits_by_reviewer':False,'commits_by_reviewer':False,'remote_writes':False,
        'review':{'status':'SUPPORTED','patch_file':'simulations/run_regions.py','change':'Expose resolved repository root only when executed directly as __main__ without a package. Module invocation remains unchanged.',
                  'falsification':'Pre-repair direct launch fails with ModuleNotFoundError; post-repair direct/module launches agree in both modes and differ from retained original only at runner source hash.',
                  'model_law_changed':False,'new_physical_claim':False,
                  'limits':'Lint covers Typst/LaTeX diagnostics; unit passes do not extend finite applications into unimplemented physical dynamics. GPU skips are retained.'}}
write('results.json',result)
report=f'''The four-line direct-launch repair is supported by execution and bounded source review. All four region commands (direct/module, normal/optimized) complete successfully and produce identical results. Recursive comparison with the retained pre-repair module output finds exactly one changed value: `$.source_sha256.runner`, from `60c1615dc041e65f379c01f1007b01df6d200860285018e9862f670eb4e3600c` to `fc4ca49704f3bdc29f5daccea0c318bdabe16294dffbbf3acdd9b9f759703d84`. No numerical, boundary, history or model field changes.

The full existing Python inventory comprises **{len(normal)} tests per mode**. Normal mode records {summary['normal']['passed']} passes and {len(summary['normal']['skipped'])} skips; optimized mode records {summary['optimized']['passed']} passes and {len(summary['optimized']['skipped'])} skips. The exact skipped device checks and reasons remain in results.json. No skipped check is reported as a GPU pass.

The environment/tool refresh interrupted the original normal run during `test_concurrent_first_publish`. Its session ceased to exist and its incomplete log is retained. A bounded isolated rerun of that in-flight test passed in {read('concurrent-reprobe.execution.json')['elapsed_seconds']:.2f} seconds, so an infinite compiler/cache hang was not reproduced. A first custom resume attempt lacked a main guard and multiprocessing re-entered its driver; that attempt was stopped and discarded from aggregate coverage, with logs preserved. Final continuation uses the standard unittest CLI. The normal inventory was completed by selecting {len(prior)} prior completed IDs and executing {len(remaining)} other IDs; {len(repeated_prior)} earlier successes with multiline docstring output were omitted by the initial resume parser and therefore ran again. They are counted once in the final inventory. Optimized standard discovery executed all {len(optimized)} IDs. These are exact matching inventories, not an inferred pass for an unfinished run. Exact argv, standard logs and extracted per-test outcomes make the continuation auditable.

Pinned aod-lint `{lint['revision']}` passes its digest and strict checks for all **{lint['manuscript_file_count']} Typst manuscripts**. Its scope is manuscript diagnostics; compiler/runtime correctness uses the separate tests. No manuscript text or ontology was changed by this repair.

Review found no further implementation issue in the patch. `ROOT` comes from the resolved script location, and insertion occurs only for direct execution (`__name__ == "__main__"` with no package). The documented `make simulate-regions` command can therefore import repository packages while ordinary module invocation retains its existing path behavior. This is an import repair; the native current model and transition laws remain unchanged.

All {len(before)} tracked source-file hashes match before/after validation. Commands, raw logs, binding, lint diagnostics, exact output comparisons and full test IDs are saved beside this report. The reviewer made no source changes, commits or remote writes. The parent owns final evidence integration and commit metadata.
'''
(OUT/'REPORT.md').write_text(report)
print(json.dumps({'status':result['status'],'tests':{m:{'total':summary[m]['tests'],'passed':summary[m]['passed'],'skipped':len(summary[m]['skipped'])} for m in summary},'lint':lint['status'],'source_changed':changed}))
