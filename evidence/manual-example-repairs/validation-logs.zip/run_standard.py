"""Run standard unittest CLI, retaining an exact inventory and subprocess status."""
from pathlib import Path
import hashlib
import json
import os
import signal
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent / 'aod-dec'
PY = OUT.parent.parent / 'AOD_M3_COMPARISON_EXECUTION_R02_2026-11-08/runtime/bin/python'


def main():
    mode=sys.argv[1]
    if mode=='normal-remaining':
        inventory=json.loads((OUT/'normal-resume-harness-aborted.inventory.json').read_text())
        selected=inventory['selected_ids']
        command=[str(PY),'-B','-m','unittest','-v',*selected]
    elif mode=='optimized':
        inventory={'mode':mode,'scope':'Full standard unittest discovery'}
        command=[str(PY),'-B','-O','-m','unittest','discover','-s','tests','-p','test_*.py','-v']
    else:raise ValueError(mode)
    prefix='standard-'+mode
    overrides={'PYTHONDONTWRITEBYTECODE':'1','PYTHONPATH':str(ROOT/'tests')+os.pathsep+str(ROOT)}
    record={'mode':mode,'command':command,'cwd':str(ROOT),'environment_overrides':overrides,
            'inventory':inventory,'timeout_seconds':1200,
            'stdout':prefix+'.stdout.log','stderr':prefix+'.stderr.log'}
    (OUT/(prefix+'.start.json')).write_text(json.dumps(record,indent=2)+'\n')
    start=time.monotonic()
    with (OUT/record['stdout']).open('w') as stdout,(OUT/record['stderr']).open('w') as stderr:
        proc=subprocess.Popen(command,cwd=ROOT,env=dict(os.environ,**overrides),stdout=stdout,stderr=stderr,start_new_session=True)
        try:
            code=proc.wait(timeout=1200)
            status='PASS' if code==0 else 'FAIL'
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid,signal.SIGTERM);proc.wait(timeout=15)
            code=124;status='TIMEOUT'
        except KeyboardInterrupt:
            os.killpg(proc.pid,signal.SIGINT);proc.wait(timeout=15)
            code=130;status='INTERRUPTED'
    record.update(status=status,exit_code=code,elapsed_seconds=time.monotonic()-start)
    for name in ['stdout','stderr']:
        record[name+'_sha256']=hashlib.sha256((OUT/record[name]).read_bytes()).hexdigest()
    (OUT/(prefix+'.execution.json')).write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps({k:record[k] for k in ['mode','status','exit_code','elapsed_seconds']}),flush=True)
    return code


if __name__=='__main__':raise SystemExit(main())
