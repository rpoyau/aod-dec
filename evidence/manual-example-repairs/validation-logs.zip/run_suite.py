"""Resume an interrupted test inventory with per-test durable completion records."""
import faulthandler
import json
from pathlib import Path
import sys
import time
import unittest

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent / 'aod-dec'
sys.path.insert(0, str(ROOT))


def flatten(suite):
    for item in suite:
        if isinstance(item, unittest.TestSuite):
            yield from flatten(item)
        else:
            yield item


class RecordedResult(unittest.TextTestResult):
    def startTest(self, test):
        self.started = time.monotonic()
        super().startTest(test)

    def stopTest(self, test):
        failure = next((text for item,text in self.failures if item == test), None)
        error = next((text for item,text in self.errors if item == test), None)
        skipped = next((text for item,text in self.skipped if item == test), None)
        row = {'test':test.id(), 'elapsed_seconds':time.monotonic()-self.started,
               'status':'ERROR' if error else 'FAIL' if failure else 'SKIP' if skipped else 'PASS',
               'reason':error or failure or skipped}
        events.write(json.dumps(row) + '\n');events.flush()
        super().stopTest(test)


def main():
    global events
    mode = sys.argv[1]
    skip = set(json.loads((OUT / 'normal-completed-ids.json').read_text())) if mode == 'normal-remaining' else set()
    suite = unittest.defaultTestLoader.discover(str(ROOT / 'tests'), pattern='test_*.py')
    all_tests = list(flatten(suite))
    selected = [test for test in all_tests if test.id() not in skip]
    if mode == 'guard-probe':
        selected = [test for test in all_tests if test.id() == 'test_routing_parallel.ParallelRoutingTests.test_process_pool_matches_scalar']
        if not selected:
            selected = [test for test in all_tests if 'test_routing_parallel' in test.id()]
    inventory = {'mode':mode, 'total_discovered':len(all_tests), 'excluded_completed':len(skip),
                 'selected':len(selected), 'selected_ids':[test.id() for test in selected],
                 'excluded_not_in_inventory':sorted(skip - {test.id() for test in all_tests})}
    (OUT / (mode + '.inventory.json')).write_text(json.dumps(inventory, indent=2) + '\n')
    if inventory['excluded_not_in_inventory']:
        raise RuntimeError('Previously completed test not in current inventory')
    events = (OUT / (mode + '.events.jsonl')).open('w')
    faulthandler.enable()
    faulthandler.dump_traceback_later(180, repeat=True)
    start = time.monotonic()
    result = unittest.TextTestRunner(verbosity=2, resultclass=RecordedResult).run(unittest.TestSuite(selected))
    faulthandler.cancel_dump_traceback_later()
    events.close()
    summary = {'mode':mode, 'command':sys.orig_argv, 'tests':result.testsRun, 'skipped':len(result.skipped),
               'failures':[(test.id(),text) for test,text in result.failures],
               'errors':[(test.id(),text) for test,text in result.errors],
               'skip_reasons':[(test.id(),text) for test,text in result.skipped],
               'elapsed_seconds':time.monotonic()-start, 'status':'PASS' if result.wasSuccessful() else 'FAIL'}
    (OUT / (mode + '.results.json')).write_text(json.dumps(summary, indent=2) + '\n')
    return 0 if result.wasSuccessful() else 1


if __name__ == '__main__':
    raise SystemExit(main())
