from pathlib import Path
import concurrent.futures
import hashlib
import json
import os
import re
import subprocess
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent / 'aod-dec'
WORK = OUT.parent.parent
PY = WORK / 'AOD_M3_COMPARISON_EXECUTION_R02_2026-11-08/runtime/bin/python'
OLD = WORK / 'AOD_DEC_MANUAL_TESTS_2026-11-14/dec-applications'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def snapshot():
    paths = subprocess.check_output(['git','ls-files','-z'], cwd=ROOT).decode().split('\0')
    return {p:sha(ROOT/p) for p in paths if p and (ROOT/p).is_file()}


before = snapshot()
write(OUT/'source-before.json', before)
write(OUT/'binding.json', {'root':str(ROOT), 'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(), 'python':str(PY), 'python_sha256':sha(PY), 'runner_sha256':sha(ROOT/'simulations/run_regions.py'), 'source_files':len(before)})


def execute(name, args):
    start=time.monotonic()
    env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
    with (OUT/(name+'.stdout.log')).open('w') as stdout, (OUT/(name+'.stderr.log')).open('w') as stderr:
        proc=subprocess.run([str(x) for x in args],cwd=ROOT,env=env,stdout=stdout,stderr=stderr)
    row={'name':name,'command':[str(x) for x in args], 'cwd':str(ROOT),'environment_overrides':{'PYTHONDONTWRITEBYTECODE':'1'},'exit_code':proc.returncode,'elapsed_seconds':time.monotonic()-start,'stdout':name+'.stdout.log','stderr':name+'.stderr.log'}
    row['stdout_sha256']=sha(OUT/row['stdout']);row['stderr_sha256']=sha(OUT/row['stderr'])
    write(OUT/(name+'.execution.json'),row)
    print(json.dumps(row),flush=True)
    return row


def lint():
    return execute('aod-lint',[PY,'-B','scripts/check_aod_lint.py','--checkout',WORK/'AOD_DEC_PR_2026-11-13/tools/aod-lint','--binary',WORK/'AOD_DEC_PR_2026-11-13/checks/lint-target/debug/aod-lint','--output',OUT/'aod-lint.json'])


def suites():
    return [execute('unittest-'+mode,[PY,'-B']+flags+['-m','unittest','discover','-s','tests','-p','test_*.py','-v']) for mode,flags in [('normal',[]),('optimized',['-O'])]]


rows=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    lf=pool.submit(lint)
    sf=pool.submit(suites)
    for mode,flags in [('normal',[]),('optimized',['-O'])]:
        for kind,prefix in [('direct',['simulations/run_regions.py']),('module',['-m','simulations.run_regions'])]:
            rows.append(execute(f'regions-{kind}-{mode}',[PY,'-B']+flags+prefix+['--example','all','--output',OUT/f'regions-{kind}-{mode}.json']))
    rows.append(lf.result());rows.extend(sf.result())
write(OUT/'executions.json',rows)
after=snapshot();write(OUT/'source-after.json',after)
changed=[p for p in sorted(set(before)|set(after)) if before.get(p)!=after.get(p)]
comparisons=[]
def without_runner(value, path=()):
    if isinstance(value,dict):
        return {k:without_runner(v,path+(k,)) for k,v in value.items()
                if not (path==('source_sha256',) and k=='runner')}
    if isinstance(value,list):return [without_runner(v,path+(i,)) for i,v in enumerate(value)]
    return value
for mode in ['normal','optimized']:
    direct=json.loads((OUT/f'regions-direct-{mode}.json').read_text())
    module=json.loads((OUT/f'regions-module-{mode}.json').read_text())
    original=json.loads((OLD/mode/'regions-controls.json').read_text())
    comparisons.append({'mode':mode,'direct_module_identical':direct==module,'original_equal_except_runner_sha256':without_runner(direct)==without_runner(original)})
    if not comparisons[-1]['original_equal_except_runner_sha256']:
        # Locate exact changed paths without assuming provenance schema.
        def diffs(a,b,p='$'):
            if type(a)!=type(b):return [p]
            if isinstance(a,dict):return [q for k in set(a)|set(b) for q in (diffs(a[k],b[k],p+'.'+k) if k in a and k in b else [p+'.'+k])]
            if isinstance(a,list):return ([p+'.length'] if len(a)!=len(b) else [q for i,(x,y) in enumerate(zip(a,b)) for q in diffs(x,y,p+f'[{i}]')])
            return [] if a==b else [p]
        comparisons[-1]['changed_paths']=diffs(original,direct)
summaries=[]
for mode in ['normal','optimized']:
    log=(OUT/f'unittest-{mode}.stderr.log').read_text()
    count=re.search(r'Ran (\d+) tests? in ([\d.]+)s',log)
    summaries.append({'mode':mode,'tests':int(count.group(1)) if count else None,'summary':log.splitlines()[-1] if log.splitlines() else '', 'skips':[line for line in log.splitlines() if ' ... skipped ' in line], 'failures':[line for line in log.splitlines() if line.startswith(('FAIL:','ERROR:'))]})
write(OUT/'results.json',{'status':'PASS' if all(r['exit_code']==0 for r in rows) and not changed and all(x['direct_module_identical'] and x['original_equal_except_runner_sha256'] for x in comparisons) else 'REVIEW_REQUIRED','executions':rows,'source_changed':changed,'comparisons':comparisons,'unittest':summaries,'aod_lint':json.loads((OUT/'aod-lint.json').read_text())['status']})
